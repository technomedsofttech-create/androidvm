# JNI entry points
-keep class com.teresa.vmmanager.runtime.NativeQemu { native <methods>; }
