package com.teresa.vmmanager.core;

import com.teresa.vmmanager.core.adb.GuestPackages;
import com.teresa.vmmanager.core.qemu.DiskImages;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class GuestPackagesTest {
    @Test
    public void parsesLaunchableActivities() {
        String out = "com.android.settings/.Settings\n  org.mozilla.firefox/org.mozilla.fenix.HomeActivity\r\n"
                + "com.android.settings/.Other\njunk line\n";
        assertEquals(Arrays.asList("com.android.settings", "org.mozilla.firefox"), GuestPackages.parseLaunchable(out));
    }

    @Test
    public void parsesListPackages() {
        assertEquals(Arrays.asList("a.b", "com.x.y"), GuestPackages.parseListPackages("package:com.x.y\npackage:a.b\nwarning\n"));
    }

    @Test
    public void rejectsShellInjection() {
        assertFalse(GuestPackages.isPackageName("com.x;reboot"));
        assertFalse(GuestPackages.isPackageName("com.x y"));
        try {
            GuestPackages.launchCommand("a.b && rm -rf /");
            fail();
        } catch (IllegalArgumentException expected) {
        }
        assertEquals("monkey -p com.a.b -c android.intent.category.LAUNCHER 1", GuestPackages.launchCommand("com.a.b"));
    }

    @Test
    public void labelsAndInstallResult() {
        assertEquals("My App", GuestPackages.guessLabel("com.example.my_app"));
        assertTrue(GuestPackages.installSucceeded("Success\n"));
        assertFalse(GuestPackages.installSucceeded("Failure [INSTALL_FAILED_NO_MATCHING_ABIS]"));
    }

    @Test
    public void detectsImageKinds() throws Exception {
        byte[] q = new byte[64];
        q[0] = 'Q'; q[1] = 'F'; q[2] = 'I'; q[3] = (byte) 0xFB;
        assertEquals(DiskImages.Kind.QCOW2, DiskImages.detect(new ByteArrayInputStream(q)));
        byte[] iso = new byte[0x9000];
        System.arraycopy("CD001".getBytes(), 0, iso, 0x8001, 5);
        assertEquals(DiskImages.Kind.ISO, DiskImages.detect(new ByteArrayInputStream(iso)));
        assertEquals(DiskImages.Kind.RAW, DiskImages.detect(new ByteArrayInputStream(new byte[10])));
        assertEquals(Arrays.asList("qemu-img", "create", "-f", "qcow2", "-b", "/b.img", "-F", "raw", "/o.qcow2"),
                DiskImages.createOverlayArgs("qemu-img", "/b.img", DiskImages.Kind.RAW, "/o.qcow2"));
    }
}
