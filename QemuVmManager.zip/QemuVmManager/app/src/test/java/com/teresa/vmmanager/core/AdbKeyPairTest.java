package com.teresa.vmmanager.core;

import com.teresa.vmmanager.core.adb.AdbKeyPair;
import org.junit.Test;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Base64;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class AdbKeyPairTest {
    @Test
    public void androidPublicKeyIsSelfConsistent() throws Exception {
        AdbKeyPair k = AdbKeyPair.generate();
        String line = k.androidPublicKey("vmmanager@phone");
        assertTrue(line.endsWith(" vmmanager@phone"));
        byte[] raw = Base64.getDecoder().decode(line.substring(0, line.indexOf(' ')));
        assertEquals(524, raw.length);
        ByteBuffer b = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);
        assertEquals(64, b.getInt());
        int n0inv = b.getInt();
        BigInteger n = readWords(b, 64);
        BigInteger rr = readWords(b, 64);
        assertEquals(65537, b.getInt());
        BigInteger r32 = BigInteger.ONE.shiftLeft(32);
        // n0inv * n == -1 (mod 2^32)
        assertEquals(r32.subtract(BigInteger.ONE), n.multiply(BigInteger.valueOf(n0inv & 0xffffffffL)).mod(r32));
        assertEquals(BigInteger.ONE.shiftLeft(4096).mod(n), rr);
        assertEquals(256, k.signToken(new byte[20]).length);
    }

    static BigInteger readWords(ByteBuffer b, int words) {
        BigInteger v = BigInteger.ZERO;
        for (int i = 0; i < words; i++)
            v = v.or(BigInteger.valueOf(b.getInt() & 0xffffffffL).shiftLeft(32 * i));
        return v;
    }
}
