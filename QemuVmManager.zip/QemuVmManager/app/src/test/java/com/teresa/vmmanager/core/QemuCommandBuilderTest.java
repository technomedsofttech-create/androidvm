package com.teresa.vmmanager.core;

import com.teresa.vmmanager.core.qemu.GuestArch;
import com.teresa.vmmanager.core.qemu.GuestProfile;
import com.teresa.vmmanager.core.qemu.QemuCommandBuilder;
import com.teresa.vmmanager.core.qemu.RuntimeEnv;
import com.teresa.vmmanager.core.qemu.VmConfig;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class QemuCommandBuilderTest {

    static VmConfig x86() {
        VmConfig c = new VmConfig();
        c.id = "ab12cd34";
        c.name = "Work phone";
        c.profile = GuestProfile.ANDROID_13;
        c.arch = GuestArch.X86_64;
        c.diskPath = "/data/vms/ab12cd34/disk.qcow2";
        return c;
    }

    static RuntimeEnv env() {
        return new RuntimeEnv("/data/qemu", "/data/vms/ab12cd34/qmp.sock", "/data/vms/ab12cd34/vnc.sock",
                "/data/vms/ab12cd34/serial.log", 16556);
    }

    static String valueAfter(List<String> a, String flag, String prefix) {
        for (int i = 0; i < a.size() - 1; i++)
            if (a.get(i).equals(flag) && a.get(i + 1).startsWith(prefix)) return a.get(i + 1);
        return null;
    }

    @Test
    public void x86GuestUsesQ35TcgAndPrivateSockets() {
        List<String> a = QemuCommandBuilder.build(x86(), env());
        assertEquals("qemu-system-x86_64", a.get(0));
        assertEquals("q35,vmport=off,i8042=on", valueAfter(a, "-machine", ""));
        assertEquals("tcg,thread=multi,tb-size=256", valueAfter(a, "-accel", ""));
        assertEquals("4096M", valueAfter(a, "-m", ""));
        assertEquals("unix:/data/vms/ab12cd34/vnc.sock", valueAfter(a, "-vnc", ""));
        assertEquals("unix:/data/vms/ab12cd34/qmp.sock,server=on,wait=off", valueAfter(a, "-qmp", ""));
        assertEquals("user,id=net0,hostfwd=tcp:127.0.0.1:16556-:5555", valueAfter(a, "-netdev", ""));
        assertTrue(valueAfter(a, "-drive", "file=").contains("format=qcow2"));
        assertEquals("virtio-vga", valueAfter(a, "-device", "virtio-vga"));
        assertEquals("usb-tablet,bus=xhci.0", valueAfter(a, "-device", "usb-tablet"));
        assertFalse("no kernel unless configured", a.contains("-kernel"));
        assertFalse("no TCP VNC", a.toString().contains("0.0.0.0"));
    }

    @Test
    public void isoAndDirectKernelBoot() {
        VmConfig c = x86();
        c.isoPath = "/data/images/bliss,16.iso";
        c.kernelPath = "/data/vms/k";
        c.initrdPath = "/data/vms/i";
        List<String> a = QemuCommandBuilder.build(c, env());
        assertTrue("comma escaped", valueAfter(a, "-drive", "file=/data/images/bliss").contains("bliss,,16.iso"));
        assertEquals("ide-cd,drive=cd0,bootindex=0", valueAfter(a, "-device", "ide-cd"));
        assertTrue(valueAfter(a, "-append", "").contains("HWACCEL=0"));
    }

    @Test
    public void aarch64GuestUsesVirtAndFirmware() {
        VmConfig c = x86();
        c.arch = GuestArch.AARCH64;
        c.profile = GuestProfile.ANDROID_15;
        c.firmwarePath = "/data/qemu/edk2-aarch64-code.fd";
        c.diskPath = "/data/vms/x/system.img";
        List<String> a = QemuCommandBuilder.build(c, env());
        assertEquals("qemu-system-aarch64", a.get(0));
        assertEquals("virt,gic-version=3,highmem=on", valueAfter(a, "-machine", ""));
        assertEquals("/data/qemu/edk2-aarch64-code.fd", valueAfter(a, "-bios", ""));
        assertTrue(valueAfter(a, "-drive", "file=").contains("format=raw"));
        assertEquals("virtio-gpu-pci", valueAfter(a, "-device", "virtio-gpu"));
    }

    @Test
    public void invalidConfigIsRejected() {
        VmConfig c = x86();
        c.ramMb = 512;
        c.id = "../etc";
        try {
            QemuCommandBuilder.build(c, env());
            fail("expected rejection");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("RAM"));
            assertTrue(e.getMessage().contains("id"));
        }
    }
}
