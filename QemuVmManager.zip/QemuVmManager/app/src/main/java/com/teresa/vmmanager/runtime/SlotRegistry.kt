package com.teresa.vmmanager.runtime

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * Which VM runs in which process slot. Each slot process writes its own file; any process can
 * read them. A slot whose recorded pid is gone counts as free, so a QEMU crash (which kills the
 * slot process outright) never leaves a slot permanently "busy".
 */
class SlotRegistry(context: Context) {
    private val dir = File(context.filesDir, "slots").apply { mkdirs() }

    enum class State { STARTING, RUNNING, STOPPING, STOPPED, FAILED }

    /** [pid] is -1 while the main process has reserved the slot but the service hasn't started yet. */
    data class Slot(
        val index: Int,
        val vmId: String,
        val pid: Int,
        val state: State,
        val message: String?,
        val updatedAt: Long = System.currentTimeMillis(),
    ) {
        /** Host port forwarded to this slot's guest adbd. */
        val adbHostPort get() = adbPort(index)
    }

    fun read(index: Int): Slot? {
        val f = file(index)
        if (!f.isFile) return null
        return runCatching {
            val o = JSONObject(f.readText())
            Slot(index, o.getString("vmId"), o.getInt("pid"), State.valueOf(o.getString("state")),
                o.optString("message").ifEmpty { null }, o.optLong("updatedAt"))
        }.getOrNull()
    }

    fun write(slot: Slot) {
        val o = JSONObject()
            .put("vmId", slot.vmId).put("pid", slot.pid).put("state", slot.state.name)
            .put("message", slot.message ?: "").put("updatedAt", slot.updatedAt)
        val tmp = File(dir, "${slot.index}.json.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(file(slot.index))
    }

    /** Live slots only (process still exists and not stopped). */
    fun live(): List<Slot> = (0 until SLOT_COUNT).mapNotNull { read(it) }.filter { isLive(it) }

    fun slotFor(vmId: String): Slot? = live().firstOrNull { it.vmId == vmId }

    fun freeSlot(): Int? = (0 until SLOT_COUNT).firstOrNull { i -> read(i)?.let { !isLive(it) } ?: true }

    /** Last recorded outcome for a VM that is no longer live (e.g. "FAILED: qemu exited 1"). */
    fun lastResult(vmId: String): Slot? =
        (0 until SLOT_COUNT).mapNotNull { read(it) }.firstOrNull { it.vmId == vmId && !isLive(it) }

    private fun isLive(s: Slot): Boolean {
        if (s.state == State.STOPPED || s.state == State.FAILED) return false
        if (s.pid <= 0) return System.currentTimeMillis() - s.updatedAt < RESERVATION_TIMEOUT_MS
        return File("/proc/${s.pid}").exists()
    }

    private fun file(index: Int) = File(dir, "$index.json")

    companion object {
        const val SLOT_COUNT = 4
        private const val RESERVATION_TIMEOUT_MS = 30_000L
        fun adbPort(index: Int) = 16555 + index
    }
}
