package com.teresa.vmmanager.core.adb;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Parsing and command strings for package-level operations inside the guest. */
public final class GuestPackages {
    private GuestPackages() {
    }

    /** User-installed packages that have a launcher activity. */
    public static final String LIST_LAUNCHABLE =
            "cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.LAUNCHER";

    /** Parses "pkg/activity" lines from {@link #LIST_LAUNCHABLE}; returns sorted unique package names. */
    public static List<String> parseLaunchable(String output) {
        List<String> pkgs = new ArrayList<>();
        for (String raw : output.split("\n")) {
            String line = raw.trim();
            int slash = line.indexOf('/');
            if (slash <= 0) continue;
            String pkg = line.substring(0, slash);
            if (isPackageName(pkg) && !pkgs.contains(pkg)) pkgs.add(pkg);
        }
        Collections.sort(pkgs);
        return pkgs;
    }

    /** Parses "package:com.example" lines from "cmd package list packages". */
    public static List<String> parseListPackages(String output) {
        List<String> pkgs = new ArrayList<>();
        for (String raw : output.split("\n")) {
            String line = raw.trim();
            if (!line.startsWith("package:")) continue;
            String pkg = line.substring("package:".length());
            if (isPackageName(pkg)) pkgs.add(pkg);
        }
        Collections.sort(pkgs);
        return pkgs;
    }

    /** monkey resolves the launcher activity itself, so we don't need the component name. */
    public static String launchCommand(String pkg) {
        requirePackage(pkg);
        return "monkey -p " + pkg + " -c android.intent.category.LAUNCHER 1";
    }

    public static String forceStopCommand(String pkg) {
        requirePackage(pkg);
        return "am force-stop " + pkg;
    }

    public static boolean installSucceeded(String output) {
        return output != null && output.contains("Success");
    }

    /** Strict check: the name is interpolated into a guest shell command. */
    public static boolean isPackageName(String s) {
        return s != null && s.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+");
    }

    private static void requirePackage(String pkg) {
        if (!isPackageName(pkg)) throw new IllegalArgumentException("invalid package name: " + pkg);
    }

    /** Readable fallback label: "com.example.my_app" -> "My App". */
    public static String guessLabel(String pkg) {
        String last = pkg.substring(pkg.lastIndexOf('.') + 1).replace('_', ' ');
        StringBuilder sb = new StringBuilder();
        for (String w : last.split(" ")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.length() == 0 ? pkg : sb.toString();
    }
}
