package com.teresa.vmmanager.guest

import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.teresa.vmmanager.core.adb.AdbConnection
import com.teresa.vmmanager.core.adb.AdbKeyPair
import com.teresa.vmmanager.core.adb.GuestPackages
import com.teresa.vmmanager.data.VmStore
import com.teresa.vmmanager.runtime.SlotRegistry
import com.teresa.vmmanager.runtime.TcpTransport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.IOException

/**
 * Talks to a running guest's adbd through the slot's 127.0.0.1 host-forward.
 * All calls are blocking network I/O and run on Dispatchers.IO.
 */
class GuestAdb(private val context: Context, private val store: VmStore) {
    private val slots = SlotRegistry(context)

    private val key: AdbKeyPair by lazy { AdbKeyPair.loadOrCreate(store.adbKeyDir.toPath()) }

    private fun keyName() = "vmmanager@${Build.MODEL.replace(' ', '_')}"

    /**
     * Connects, retrying while the guest boots (adbd only comes up late in Android's boot).
     * [onWaitingForApproval] fires once if the guest shows the "Allow debugging?" prompt.
     */
    suspend fun connect(
        vmId: String,
        bootTimeoutMs: Long = 20 * 60_000L,
        onWaitingForApproval: () -> Unit = {},
        onAttempt: (Int) -> Unit = {},
    ): AdbConnection = withContext(Dispatchers.IO) {
        withTimeout(bootTimeoutMs) {
            var attempt = 0
            while (true) {
                attempt++
                onAttempt(attempt)
                val slot = slots.slotFor(vmId) ?: throw IOException("VM is not running")
                val conn = runCatching {
                    AdbConnection.connect(
                        TcpTransport(slot.adbHostPort), key, keyName(),
                        { onWaitingForApproval() }, IO_TIMEOUT_MS, APPROVAL_TIMEOUT_MS,
                    )
                }.getOrNull()
                if (conn != null && isBootCompleted(conn)) return@withTimeout conn
                runCatching { conn?.close() }
                delay(RETRY_DELAY_MS)
            }
            @Suppress("UNREACHABLE_CODE")
            throw IllegalStateException()
        }
    }

    private fun isBootCompleted(c: AdbConnection): Boolean =
        runCatching { c.exec("getprop sys.boot_completed").trim() == "1" }.getOrDefault(false)

    suspend fun launchableApps(conn: AdbConnection): List<String> = withContext(Dispatchers.IO) {
        GuestPackages.parseLaunchable(conn.exec(GuestPackages.LIST_LAUNCHABLE))
    }

    suspend fun launch(conn: AdbConnection, pkg: String): String = withContext(Dispatchers.IO) {
        conn.exec(GuestPackages.launchCommand(pkg))
    }

    /** Android key codes: 3 = HOME, 4 = BACK, 187 = APP_SWITCH, 26 = POWER. */
    suspend fun keyEvent(conn: AdbConnection, androidKeyCode: Int) = withContext(Dispatchers.IO) {
        conn.exec("input keyevent $androidKeyCode")
    }

    /** Streams an APK from a content URI straight into the guest's package manager. */
    suspend fun install(conn: AdbConnection, apk: Uri, onProgress: (Long, Long) -> Unit): String =
        withContext(Dispatchers.IO) {
            val size = context.contentResolver.query(apk, arrayOf(OpenableColumns.SIZE), null, null, null)
                ?.use { if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L } ?: -1L
            if (size <= 0) throw IOException("Can't determine the APK size")
            val output = context.contentResolver.openInputStream(apk)?.use { input ->
                conn.install(input.buffered(1 shl 16), size) { sent, total -> onProgress(sent, total) }
            } ?: throw IOException("Can't open the APK")
            if (!GuestPackages.installSucceeded(output)) throw IOException(output.trim().ifEmpty { "install failed" })
            output.trim()
        }

    companion object {
        private const val IO_TIMEOUT_MS = 15_000
        private const val APPROVAL_TIMEOUT_MS = 120_000
        private const val RETRY_DELAY_MS = 3_000L
    }
}
