package com.teresa.vmmanager.runtime

import android.content.Context
import com.teresa.vmmanager.core.qemu.GuestArch
import java.io.File

/**
 * Locates the QEMU binaries packaged in jniLibs and the firmware/ROM data in assets.
 *
 * Expected APK contents (produced by tools/build-qemu-android.sh):
 *   lib/arm64-v8a/libqemu-system-x86_64.so   QEMU x86_64, linked as a shared library
 *   lib/arm64-v8a/libqemu-system-aarch64.so  QEMU aarch64, linked as a shared library
 *   lib/arm64-v8a/libqemu-img.so             qemu-img executable (named lib*.so so it is installed)
 *   lib/arm64-v8a/lib*.so                    glib, pixman, slirp, ... dependencies
 *   assets/qemu-data/                        bios-256k.bin, vgabios-virtio.bin, efi-*.rom, edk2-aarch64-code.fd, keymaps/
 */
class QemuBinaries(private val context: Context) {
    private val nativeDir = File(context.applicationInfo.nativeLibraryDir)

    fun qemuLibrary(arch: GuestArch) = File(nativeDir, arch.libraryName)
    val qemuImg get() = File(nativeDir, "libqemu-img.so")
    val nativeLibraryDir: File get() = nativeDir

    fun isInstalled(arch: GuestArch) = qemuLibrary(arch).isFile

    fun missingPieces(): List<String> = buildList {
        GuestArch.values().forEach { if (!isInstalled(it)) add(it.libraryName) }
        if (!qemuImg.isFile) add("libqemu-img.so")
        if (context.assets.list("qemu-data").isNullOrEmpty()) add("assets/qemu-data")
    }

    /** Extracts assets/qemu-data once per app version and returns the directory (QEMU's -L). */
    @Synchronized
    fun dataDir(): File {
        val dir = File(context.filesDir, "qemu-data")
        val stamp = File(dir, ".version")
        val version = appVersion()
        if (stamp.isFile && stamp.readText() == version) return dir
        dir.deleteRecursively()
        copyAssetTree("qemu-data", dir)
        stamp.writeText(version)
        return dir
    }

    fun edk2Aarch64(): File = File(dataDir(), "edk2-aarch64-code.fd")

    private fun copyAssetTree(assetPath: String, target: File) {
        val children = context.assets.list(assetPath).orEmpty()
        if (children.isEmpty()) {
            target.parentFile?.mkdirs()
            context.assets.open(assetPath).use { input -> target.outputStream().use { input.copyTo(it) } }
            return
        }
        target.mkdirs()
        for (child in children) copyAssetTree("$assetPath/$child", File(target, child))
    }

    private fun appVersion(): String {
        @Suppress("DEPRECATION") // PackageInfoFlags overload needs API 33; minSdk is 31
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        return "${info.longVersionCode}-${info.lastUpdateTime}"
    }
}
