package com.teresa.vmmanager.core.adb;

import com.teresa.vmmanager.core.io.Wire;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** One ADB transport packet: 24-byte little-endian header plus payload. */
public final class AdbMessage {
    public static final int A_SYNC = 0x434e5953;
    public static final int A_CNXN = 0x4e584e43;
    public static final int A_OPEN = 0x4e45504f;
    public static final int A_OKAY = 0x59414b4f;
    public static final int A_CLSE = 0x45534c43;
    public static final int A_WRTE = 0x45545257;
    public static final int A_AUTH = 0x48545541;

    public static final int AUTH_TOKEN = 1;
    public static final int AUTH_SIGNATURE = 2;
    public static final int AUTH_RSAPUBLICKEY = 3;

    public static final int VERSION = 0x01000001;
    public static final int MAX_PAYLOAD = 256 * 1024;

    public final int command;
    public final int arg0;
    public final int arg1;
    public final byte[] data;

    public AdbMessage(int command, int arg0, int arg1, byte[] data) {
        this.command = command;
        this.arg0 = arg0;
        this.arg1 = arg1;
        this.data = data == null ? new byte[0] : data;
    }

    public void writeTo(OutputStream out) throws IOException {
        ByteBuffer h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        h.putInt(command).putInt(arg0).putInt(arg1).putInt(data.length).putInt(checksum(data)).putInt(~command);
        out.write(h.array());
        if (data.length > 0) out.write(data);
        out.flush();
    }

    public static AdbMessage readFrom(InputStream in) throws IOException {
        ByteBuffer h = ByteBuffer.wrap(Wire.readFully(in, 24)).order(ByteOrder.LITTLE_ENDIAN);
        int cmd = h.getInt(), a0 = h.getInt(), a1 = h.getInt(), len = h.getInt();
        h.getInt(); // checksum: ignored for protocol >= 0x01000001
        int magic = h.getInt();
        if (magic != ~cmd) throw new IOException("bad adb magic for " + name(cmd));
        if (len < 0 || len > MAX_PAYLOAD) throw new IOException("bad adb payload length " + len);
        return new AdbMessage(cmd, a0, a1, len == 0 ? new byte[0] : Wire.readFully(in, len));
    }

    static int checksum(byte[] d) {
        int s = 0;
        for (byte b : d) s += b & 0xff;
        return s;
    }

    public static String name(int cmd) {
        byte[] b = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(cmd).array();
        return new String(b, java.nio.charset.StandardCharsets.US_ASCII);
    }

    @Override
    public String toString() {
        return name(command) + "(" + arg0 + "," + arg1 + "," + data.length + "B)";
    }
}
