package com.teresa.vmmanager.runtime

import android.content.Context
import android.content.Intent
import com.teresa.vmmanager.core.qemu.DiskImages
import com.teresa.vmmanager.data.VmStore
import java.io.File
import java.io.IOException

/** Main-process API for starting/stopping VMs and querying where each one runs. */
class VmController(private val context: Context, private val store: VmStore) {
    val slots = SlotRegistry(context)

    sealed interface Status {
        data object Stopped : Status
        data class Failed(val message: String) : Status
        data class Active(val slot: SlotRegistry.Slot) : Status
    }

    fun status(vmId: String): Status {
        slots.slotFor(vmId)?.let { return Status.Active(it) }
        val last = slots.lastResult(vmId)
        if (last?.state == SlotRegistry.State.FAILED) return Status.Failed(last.message ?: "failed")
        return Status.Stopped
    }

    /** Starts the VM in a free slot process, or returns the slot it already runs in. */
    @Synchronized
    fun start(vmId: String): SlotRegistry.Slot {
        slots.slotFor(vmId)?.let { return it }
        val binaries = QemuBinaries(context)
        val arch = store.load(vmId).arch
        if (!binaries.isInstalled(arch)) {
            throw IOException("This build has no QEMU for ${arch.name}. Missing: ${binaries.missingPieces().joinToString()}")
        }
        val index = slots.freeSlot()
            ?: throw IOException("All ${SlotRegistry.SLOT_COUNT} VM slots are in use. Stop a VM first.")
        val reserved = SlotRegistry.Slot(index, vmId, -1, SlotRegistry.State.STARTING, null)
        slots.write(reserved)
        val intent = Intent(context, VmSlotService.serviceClass(index))
            .setAction(VmSlotService.ACTION_START)
            .putExtra(VmSlotService.EXTRA_VM_ID, vmId)
        context.startForegroundService(intent)
        return reserved
    }

    /** ACPI power button, then a hard quit after a grace period. */
    fun stop(vmId: String) = send(vmId, VmSlotService.ACTION_STOP)

    /** Immediate QEMU exit (like pulling the plug). */
    fun forceStop(vmId: String) = send(vmId, VmSlotService.ACTION_KILL)

    private fun send(vmId: String, action: String) {
        val slot = slots.slotFor(vmId) ?: return
        context.startService(Intent(context, VmSlotService.serviceClass(slot.index)).setAction(action))
    }

    fun isRunning(vmId: String) = slots.slotFor(vmId) != null

    // ---- disks -------------------------------------------------------------------------

    /** Creates the VM's private overlay on top of a shared base image. */
    fun createOverlay(base: File, kind: DiskImages.Kind, overlay: File) =
        runQemuImg(DiskImages.createOverlayArgs(qemuImgPath(), base.absolutePath, kind, overlay.absolutePath))

    fun createBlankDisk(path: File, sizeGb: Int) =
        runQemuImg(DiskImages.createBlankArgs(qemuImgPath(), path.absolutePath, sizeGb))

    private fun qemuImgPath(): String {
        val img = QemuBinaries(context).qemuImg
        if (!img.isFile) throw IOException("qemu-img is not bundled in this build")
        return img.absolutePath
    }

    private fun runQemuImg(args: List<String>): String {
        val pb = ProcessBuilder(args).redirectErrorStream(true)
        pb.environment()["LD_LIBRARY_PATH"] = QemuBinaries(context).nativeLibraryDir.absolutePath
        pb.environment()["TMPDIR"] = context.cacheDir.absolutePath
        val p = pb.start()
        val out = p.inputStream.bufferedReader().readText()
        val code = p.waitFor()
        if (code != 0) throw IOException("qemu-img failed ($code): ${out.trim()}")
        return out
    }
}
