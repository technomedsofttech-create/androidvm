package com.teresa.vmmanager.ui

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.teresa.vmmanager.VmApp
import com.teresa.vmmanager.core.adb.AdbConnection
import com.teresa.vmmanager.core.adb.GuestPackages
import com.teresa.vmmanager.core.qemu.VmConfig
import com.teresa.vmmanager.runtime.VmController
import com.teresa.vmmanager.shortcuts.GuestShortcuts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VmDetailActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as VmApp
        val vmId = intent.getStringExtra("vmId") ?: return finish()
        setContent { MaterialTheme { VmDetailScreen(app, vmId) { finish() } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun VmDetailScreen(app: VmApp, vmId: String, close: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var config by remember { mutableStateOf(runCatching { app.store.load(vmId) }.getOrNull()) }
    var status by remember { mutableStateOf<VmController.Status>(VmController.Status.Stopped) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    var apps by remember { mutableStateOf<List<String>?>(null) }
    var adb by remember { mutableStateOf<AdbConnection?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var logTail by remember { mutableStateOf("") }

    val cfg = config ?: run { LaunchedEffect(Unit) { close() }; return }
    val running = status is VmController.Status.Active

    LaunchedEffect(vmId) {
        while (true) {
            status = app.controller.status(vmId)
            logTail = withContext(Dispatchers.IO) {
                runCatching { app.store.qemuLog(vmId).readLines().takeLast(12).joinToString("\n") }.getOrDefault("")
            }
            if (status !is VmController.Status.Active && adb != null) {
                runCatching { adb?.close() }; adb = null; apps = null
            }
            delay(1500)
        }
    }
    DisposableEffect(Unit) { onDispose { runCatching { adb?.close() } } }

    /** Runs [block] with a booted guest's adb connection, connecting first if needed. */
    fun withGuest(label: String, block: suspend (AdbConnection) -> Unit) {
        scope.launch {
            busy = label
            message = null
            try {
                val conn = adb ?: app.guestAdb.connect(
                    vmId,
                    onWaitingForApproval = { busy = "Tap \"Allow\" on the debugging prompt inside the VM" },
                    onAttempt = { n -> if (n > 1) busy = "Waiting for the guest to finish booting…" },
                ).also { adb = it }
                busy = label
                block(conn)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                runCatching { adb?.close() }
                adb = null
                message = e.message ?: e.toString()
            } finally {
                busy = null
            }
        }
    }

    val apkPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) withGuest("Installing APK…") { conn ->
            val result = app.guestAdb.install(conn, uri) { sent, total -> busy = "Installing APK… ${sent * 100 / total}%" }
            message = "Installed: $result"
            apps = app.guestAdb.launchableApps(conn)
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text(cfg.name) }) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("${cfg.profile.label} · ${cfg.arch.name.lowercase()} · ${statusLabel(status)}",
                style = MaterialTheme.typography.titleSmall)
            (status as? VmController.Status.Failed)?.let {
                Text(it.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!running) Button(onClick = {
                    runCatching { app.controller.start(vmId) }.onFailure { message = it.message }
                    context.startActivity(DisplayActivity.intent(context, vmId))
                }) { Text("Start") }
                if (running) Button(onClick = { context.startActivity(DisplayActivity.intent(context, vmId)) }) { Text("Open screen") }
                if (running) OutlinedButton(onClick = { app.controller.stop(vmId) }) { Text("Shut down") }
                if (running) OutlinedButton(onClick = { app.controller.forceStop(vmId) }) { Text("Force stop") }
            }

            busy?.let {
                Text(it)
                LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

            HorizontalDivider()
            Text("Apps inside the VM", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = running && busy == null, onClick = {
                    apkPicker.launch(arrayOf("application/vnd.android.package-archive"))
                }) { Text("Install APK") }
                OutlinedButton(enabled = running && busy == null, onClick = {
                    withGuest("Reading installed apps…") { apps = app.guestAdb.launchableApps(it) }
                }) { Text("List apps") }
            }
            apps?.forEach { pkg ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(GuestPackages.guessLabel(pkg))
                            Text(pkg, style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = {
                            withGuest("Opening…") { app.guestAdb.launch(it, pkg) }
                            context.startActivity(DisplayActivity.intent(context, vmId))
                        }) { Text("Open") }
                        TextButton(onClick = {
                            val ok = GuestShortcuts.requestPin(context, vmId, cfg.name, pkg)
                            if (!ok) Toast.makeText(context, "Your launcher doesn't support pinned shortcuts", Toast.LENGTH_LONG).show()
                        }) { Text("Add to home") }
                    }
                }
            }

            HorizontalDivider()
            Text("Hardware", style = MaterialTheme.typography.titleMedium)
            if (running) Text("Shut the VM down to change these.", style = MaterialTheme.typography.bodySmall)
            HardwareEditor(cfg, enabled = !running) { updated ->
                runCatching { app.store.save(updated) }
                    .onSuccess { config = app.store.load(vmId); message = "Saved" }
                    .onFailure { message = it.message }
            }

            HorizontalDivider()
            Text("QEMU log", style = MaterialTheme.typography.titleMedium)
            SelectionContainer {
                Text(logTail.ifEmpty { "(empty)" }, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }

            HorizontalDivider()
            OutlinedButton(enabled = !running, onClick = { confirmDelete = true }) { Text("Delete VM") }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete ${cfg.name}?") },
        text = { Text("Its disk and everything installed in it are removed. Shared base images are kept.") },
        confirmButton = {
            TextButton(onClick = {
                GuestShortcuts.disableForVm(context, vmId)
                app.store.delete(vmId)
                close()
            }) { Text("Delete") }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
    )
}

@Composable
private fun HardwareEditor(cfg: VmConfig, enabled: Boolean, onSave: (VmConfig) -> Unit) {
    var ram by remember(cfg) { mutableStateOf(cfg.ramMb.toString()) }
    var cpus by remember(cfg) { mutableStateOf(cfg.cpus.toString()) }
    var tb by remember(cfg) { mutableStateOf(cfg.tbSizeMb.toString()) }
    var adbPort by remember(cfg) { mutableStateOf(cfg.guestAdbPort.toString()) }
    var cmdline by remember(cfg) { mutableStateOf(cfg.cmdline ?: "") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row {
            NumberField("RAM MB", ram, Modifier.weight(1f)) { ram = it }
            Spacer(Modifier.width(8.dp))
            NumberField("CPUs", cpus, Modifier.weight(1f)) { cpus = it }
        }
        Row {
            NumberField("TCG cache MB", tb, Modifier.weight(1f)) { tb = it }
            Spacer(Modifier.width(8.dp))
            NumberField("Guest adb port", adbPort, Modifier.weight(1f)) { adbPort = it }
        }
        if (!cfg.kernelPath.isNullOrEmpty()) {
            OutlinedTextField(cmdline, { cmdline = it }, Modifier.fillMaxWidth(), enabled = enabled,
                label = { Text("Kernel command line") })
        }
        cfg.isoPath?.let { Text("CD-ROM: ${it.substringAfterLast('/')}", style = MaterialTheme.typography.bodySmall) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = enabled, onClick = {
                onSave(copy(cfg).apply {
                    ramMb = ram.toIntOrNull() ?: ramMb
                    this.cpus = cpus.toIntOrNull() ?: this.cpus
                    tbSizeMb = tb.toIntOrNull() ?: tbSizeMb
                    guestAdbPort = adbPort.toIntOrNull() ?: guestAdbPort
                    this.cmdline = cmdline.ifBlank { null }
                })
            }) { Text("Save") }
            if (cfg.isoPath != null) OutlinedButton(enabled = enabled, onClick = {
                onSave(copy(cfg).apply { isoPath = null })
            }) { Text("Eject ISO") }
        }
    }
}

private fun copy(c: VmConfig): VmConfig =
    com.teresa.vmmanager.data.VmStore.fromJson(com.teresa.vmmanager.data.VmStore.toJson(c))
