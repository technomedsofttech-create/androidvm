package com.teresa.vmmanager.core.io;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

/** Small helpers for exact reads. */
public final class Wire {
    private Wire() {
    }

    public static void readFully(InputStream in, byte[] buf, int off, int len) throws IOException {
        while (len > 0) {
            int n = in.read(buf, off, len);
            if (n < 0) throw new EOFException("stream closed");
            off += n;
            len -= n;
        }
    }

    public static byte[] readFully(InputStream in, int len) throws IOException {
        byte[] b = new byte[len];
        readFully(in, b, 0, len);
        return b;
    }

    public static void skip(InputStream in, long len) throws IOException {
        byte[] scratch = new byte[(int) Math.min(len, 8192)];
        while (len > 0) {
            int chunk = (int) Math.min(len, scratch.length);
            readFully(in, scratch, 0, chunk);
            len -= chunk;
        }
    }
}
