package com.teresa.vmmanager.core.adb;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAKeyGenParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * The manager's ADB identity: one RSA-2048 key shared by all VMs, so the guest's
 * "Allow USB debugging?" prompt only has to be accepted once per guest.
 */
public final class AdbKeyPair {
    /** DER prefix of a SHA-1 DigestInfo. adbd signs the raw 20-byte token as if it were a SHA-1 digest. */
    private static final byte[] SHA1_DIGEST_INFO = {
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    };

    private final PrivateKey privateKey;
    private final RSAPublicKey publicKey;

    private AdbKeyPair(PrivateKey priv, RSAPublicKey pub) {
        this.privateKey = priv;
        this.publicKey = pub;
    }

    public static AdbKeyPair generate() throws GeneralSecurityException {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(new RSAKeyGenParameterSpec(2048, RSAKeyGenParameterSpec.F4));
        KeyPair kp = g.generateKeyPair();
        return new AdbKeyPair(kp.getPrivate(), (RSAPublicKey) kp.getPublic());
    }

    /** Loads the key from {@code dir}, creating and saving a new one on first use. */
    public static AdbKeyPair loadOrCreate(Path dir) throws IOException, GeneralSecurityException {
        Path privPath = dir.resolve("adbkey.pk8");
        Path pubPath = dir.resolve("adbkey.x509");
        if (Files.exists(privPath) && Files.exists(pubPath)) {
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PrivateKey priv = kf.generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(privPath)));
            RSAPublicKey pub = (RSAPublicKey) kf.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(pubPath)));
            return new AdbKeyPair(priv, pub);
        }
        AdbKeyPair k = generate();
        Files.createDirectories(dir);
        Files.write(privPath, k.privateKey.getEncoded());
        Files.write(pubPath, k.publicKey.getEncoded());
        return k;
    }

    /** Signs an AUTH TOKEN exactly like adb's RSA_sign(NID_sha1, token, ...). */
    public byte[] signToken(byte[] token) throws GeneralSecurityException {
        byte[] digestInfo = new byte[SHA1_DIGEST_INFO.length + token.length];
        System.arraycopy(SHA1_DIGEST_INFO, 0, digestInfo, 0, SHA1_DIGEST_INFO.length);
        System.arraycopy(token, 0, digestInfo, SHA1_DIGEST_INFO.length, token.length);
        Signature s = Signature.getInstance("NONEwithRSA");
        s.initSign(privateKey);
        s.update(digestInfo);
        return s.sign();
    }

    /**
     * Public key in Android's "mincrypt" format, base64 encoded, followed by " name".
     * This is the line adbd stores in /data/misc/adb/adb_keys.
     */
    public String androidPublicKey(String name) {
        final int words = 64; // 2048-bit modulus
        BigInteger n = publicKey.getModulus();
        BigInteger r32 = BigInteger.ONE.shiftLeft(32);
        BigInteger n0inv = r32.subtract(n.mod(r32).modInverse(r32)).mod(r32);
        BigInteger rr = BigInteger.ONE.shiftLeft(words * 32 * 2).mod(n);

        ByteBuffer b = ByteBuffer.allocate(4 + 4 + words * 4 * 2 + 4).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(words);
        b.putInt(n0inv.intValue());
        putWords(b, n, words);
        putWords(b, rr, words);
        b.putInt(publicKey.getPublicExponent().intValue());
        return Base64.getEncoder().encodeToString(b.array()) + " " + name;
    }

    byte[] androidPublicKeyPayload(String name) {
        return (androidPublicKey(name) + "\0").getBytes(StandardCharsets.US_ASCII);
    }

    private static void putWords(ByteBuffer b, BigInteger v, int words) {
        BigInteger mask = BigInteger.ONE.shiftLeft(32).subtract(BigInteger.ONE);
        for (int i = 0; i < words; i++) b.putInt(v.shiftRight(32 * i).and(mask).intValue());
    }
}
