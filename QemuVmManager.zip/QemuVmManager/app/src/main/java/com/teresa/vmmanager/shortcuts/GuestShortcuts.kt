package com.teresa.vmmanager.shortcuts

import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Icon
import com.teresa.vmmanager.core.adb.GuestPackages

/**
 * Pins home-screen shortcuts that open a guest app: tapping one boots the VM if needed and
 * launches the app inside it (see [ShortcutLaunchActivity]).
 */
object GuestShortcuts {
    const val EXTRA_VM_ID = "vmId"
    const val EXTRA_PACKAGE = "guestPackage"

    fun isSupported(context: Context): Boolean =
        context.getSystemService(ShortcutManager::class.java).isRequestPinShortcutSupported

    /** Asks the launcher to pin; the user confirms in the launcher's own dialog. */
    fun requestPin(context: Context, vmId: String, vmName: String, pkg: String, label: String = GuestPackages.guessLabel(pkg)): Boolean {
        require(GuestPackages.isPackageName(pkg))
        val manager = context.getSystemService(ShortcutManager::class.java)
        if (!manager.isRequestPinShortcutSupported) return false
        val intent = Intent(context, ShortcutLaunchActivity::class.java)
            .setAction(Intent.ACTION_VIEW)
            .putExtra(EXTRA_VM_ID, vmId)
            .putExtra(EXTRA_PACKAGE, pkg)
        val info = ShortcutInfo.Builder(context, shortcutId(vmId, pkg))
            .setShortLabel(label.take(24))
            .setLongLabel("$label ($vmName)".take(48))
            .setIcon(Icon.createWithAdaptiveBitmap(letterIcon(label, vmId)))
            .setIntent(intent)
            .build()
        return manager.requestPinShortcut(info, null)
    }

    /** Disables pinned shortcuts of a deleted VM so they show "unavailable" instead of failing. */
    fun disableForVm(context: Context, vmId: String) {
        val manager = context.getSystemService(ShortcutManager::class.java)
        val ids = manager.pinnedShortcuts.map { it.id }.filter { it.startsWith("vm-$vmId-") }
        if (ids.isNotEmpty()) manager.disableShortcuts(ids, "This VM was deleted")
    }

    private fun shortcutId(vmId: String, pkg: String) = "vm-$vmId-$pkg"

    /** 108dp adaptive-icon canvas with a coloured background (stable per VM) and the app's initial. */
    private fun letterIcon(label: String, vmId: String): Bitmap {
        val size = 432
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val hue = (vmId.hashCode().toLong() and 0xffff) % 360
        canvas.drawColor(Color.HSVToColor(floatArrayOf(hue.toFloat(), 0.55f, 0.75f)))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = size * 0.34f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        val letter = label.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "?"
        val y = size / 2f - (paint.descent() + paint.ascent()) / 2f
        canvas.drawText(letter, size / 2f, y, paint)
        return bmp
    }
}
