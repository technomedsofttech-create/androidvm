package com.teresa.vmmanager.data

import android.content.Context
import com.teresa.vmmanager.core.qemu.GuestArch
import com.teresa.vmmanager.core.qemu.GuestProfile
import com.teresa.vmmanager.core.qemu.VmConfig
import org.json.JSONObject
import java.io.File
import java.security.SecureRandom

/**
 * On-disk layout (all inside the app's private files dir):
 *
 *   images/<name>                 imported base images and ISOs, shared read-only by VMs
 *   vms/<id>/config.json          the VM's VmConfig
 *   vms/<id>/disk.qcow2           the VM's own copy-on-write overlay (its "phone storage")
 *   vms/<id>/qmp.sock, vnc.sock   control and display sockets while running
 *   vms/<id>/qemu.log, serial.log QEMU's stderr and the guest console
 *   adb/                          the manager's ADB RSA key
 *
 * Every VM is independent: deleting one only removes its own directory.
 */
class VmStore(context: Context) {
    private val files: File = context.filesDir
    val vmsDir = File(files, "vms").apply { mkdirs() }
    val imagesDir = File(files, "images").apply { mkdirs() }
    val adbKeyDir = File(files, "adb")

    fun vmDir(id: String) = File(vmsDir, id)
    fun qmpSocket(id: String) = File(vmDir(id), "qmp.sock")
    fun vncSocket(id: String) = File(vmDir(id), "vnc.sock")
    fun qemuLog(id: String) = File(vmDir(id), "qemu.log")
    fun serialLog(id: String) = File(vmDir(id), "serial.log")

    @Synchronized
    fun list(): List<VmConfig> =
        vmsDir.listFiles().orEmpty()
            .filter { File(it, CONFIG).isFile }
            .mapNotNull { runCatching { load(it.name) }.getOrNull() }
            .sortedBy { it.name.lowercase() }

    @Synchronized
    fun load(id: String): VmConfig {
        require(id.matches(ID_REGEX)) { "bad vm id" }
        return fromJson(JSONObject(File(vmDir(id), CONFIG).readText()))
    }

    @Synchronized
    fun save(config: VmConfig) {
        val errors = config.validate()
        require(errors.isEmpty()) { errors.joinToString("; ") }
        val dir = vmDir(config.id).apply { mkdirs() }
        val tmp = File(dir, "$CONFIG.tmp")
        tmp.writeText(toJson(config).toString(2))
        check(tmp.renameTo(File(dir, CONFIG))) { "could not write config" }
    }

    @Synchronized
    fun delete(id: String) {
        require(id.matches(ID_REGEX)) { "bad vm id" }
        vmDir(id).deleteRecursively()
    }

    fun newId(): String {
        val alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
        val rnd = SecureRandom()
        while (true) {
            val id = (1..8).map { alphabet[rnd.nextInt(alphabet.length)] }.joinToString("")
            if (!vmDir(id).exists()) return id
        }
    }

    companion object {
        private const val CONFIG = "config.json"
        val ID_REGEX = Regex("[a-z0-9]{4,16}")

        fun toJson(c: VmConfig) = JSONObject().apply {
            put("id", c.id)
            put("name", c.name)
            put("profile", c.profile.name)
            put("arch", c.arch.name)
            put("ramMb", c.ramMb)
            put("cpus", c.cpus)
            put("tbSizeMb", c.tbSizeMb)
            put("diskPath", c.diskPath)
            putOpt("isoPath", c.isoPath)
            putOpt("kernelPath", c.kernelPath)
            putOpt("initrdPath", c.initrdPath)
            putOpt("cmdline", c.cmdline)
            putOpt("firmwarePath", c.firmwarePath)
            put("guestAdbPort", c.guestAdbPort)
            putOpt("displayDevice", c.displayDevice)
        }

        fun fromJson(o: JSONObject) = VmConfig().apply {
            id = o.getString("id")
            name = o.getString("name")
            profile = GuestProfile.fromName(o.optString("profile"))
            arch = runCatching { GuestArch.valueOf(o.optString("arch")) }.getOrDefault(GuestArch.X86_64)
            ramMb = o.optInt("ramMb", profile.defaultRamMb)
            cpus = o.optInt("cpus", 4)
            tbSizeMb = o.optInt("tbSizeMb", 256)
            diskPath = o.getString("diskPath")
            isoPath = o.optStringOrNull("isoPath")
            kernelPath = o.optStringOrNull("kernelPath")
            initrdPath = o.optStringOrNull("initrdPath")
            cmdline = o.optStringOrNull("cmdline")
            firmwarePath = o.optStringOrNull("firmwarePath")
            guestAdbPort = o.optInt("guestAdbPort", 5555)
            displayDevice = o.optStringOrNull("displayDevice")
        }

        private fun JSONObject.optStringOrNull(key: String): String? =
            if (has(key) && !isNull(key)) getString(key).takeIf { it.isNotEmpty() } else null
    }
}
