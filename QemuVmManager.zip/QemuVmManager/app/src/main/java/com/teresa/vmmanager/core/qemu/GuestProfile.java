package com.teresa.vmmanager.core.qemu;

/**
 * The three guest Android versions this manager targets. A profile only supplies defaults;
 * every value ends up in the VM's own {@link VmConfig} and can be edited.
 */
public enum GuestProfile {
    ANDROID_12("Android 12", 32, 3072, 16),
    ANDROID_13("Android 13", 33, 4096, 16),
    ANDROID_15("Android 15", 35, 4096, 24);

    public final String label;
    public final int apiLevel;
    public final int defaultRamMb;
    public final int defaultDiskGb;

    GuestProfile(String label, int apiLevel, int defaultRamMb, int defaultDiskGb) {
        this.label = label;
        this.apiLevel = apiLevel;
        this.defaultRamMb = defaultRamMb;
        this.defaultDiskGb = defaultDiskGb;
    }

    /**
     * Kernel command line used only for direct kernel boot of an Android-x86 style image
     * (kernel + initrd extracted from the ISO). HWACCEL=0 forces software rendering, which is
     * required because there is no host GPU passthrough under TCG.
     */
    public String defaultX86Cmdline() {
        return "quiet root=/dev/ram0 androidboot.selinux=permissive HWACCEL=0 SRC=/ "
                + "androidboot.hardware=android_x86_64";
    }

    /** Kernel command line for an AOSP arm64 "virt" build using direct kernel boot. */
    public String defaultArmCmdline() {
        return "console=ttyAMA0 androidboot.hardware=qemu androidboot.selinux=permissive "
                + "androidboot.console=ttyAMA0";
    }

    public static GuestProfile fromName(String name) {
        for (GuestProfile p : values()) if (p.name().equals(name)) return p;
        return ANDROID_13;
    }
}
