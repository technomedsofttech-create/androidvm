package com.teresa.vmmanager.core.qemu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Turns a {@link VmConfig} into a QEMU argv. Pure function, no I/O, unit tested.
 *
 * Design choices that matter on a phone:
 *  - TCG only (no KVM without root), multi-threaded TCG so each vCPU gets a host thread.
 *  - VNC and QMP on unix sockets inside the app's private dir, so no other app on the phone
 *    can attach to the guest screen or control QEMU.
 *  - adb is reached through slirp host forwarding bound to 127.0.0.1 only.
 *  - usb-tablet gives absolute pointer coordinates, so touch maps 1:1 without mouse drift.
 */
public final class QemuCommandBuilder {
    private QemuCommandBuilder() {
    }

    public static List<String> build(VmConfig c, RuntimeEnv env) {
        List<String> errors = c.validate();
        if (!errors.isEmpty()) throw new IllegalArgumentException(String.join("; ", errors));

        List<String> a = new ArrayList<>();
        a.add(c.arch.argv0);
        add(a, "-L", env.qemuDataDir);
        add(a, "-name", sanitize(c.name) + ",process=vm-" + c.id);
        add(a, "-nodefaults");
        add(a, "-no-user-config");

        if (c.arch == GuestArch.X86_64) {
            add(a, "-machine", "q35,vmport=off,i8042=on");
            // "max" exposes SSE4.2/SSSE3/POPCNT etc. that Android x86_64 userspace requires.
            add(a, "-cpu", "max");
        } else {
            add(a, "-machine", "virt,gic-version=3,highmem=on");
            add(a, "-cpu", "max");
        }
        add(a, "-accel", "tcg,thread=multi,tb-size=" + c.tbSizeMb);
        add(a, "-smp", Integer.toString(c.cpus));
        add(a, "-m", c.ramMb + "M");

        if (c.arch == GuestArch.AARCH64 && !VmConfig.isEmpty(c.firmwarePath) && VmConfig.isEmpty(c.kernelPath)) {
            add(a, "-bios", c.firmwarePath);
        }
        if (!VmConfig.isEmpty(c.kernelPath)) {
            add(a, "-kernel", c.kernelPath);
            add(a, "-initrd", c.initrdPath);
            add(a, "-append", c.effectiveCmdline());
        }

        add(a, "-drive", "file=" + escapeOpt(c.diskPath) + ",if=none,id=hd0,format=" + diskFormat(c.diskPath)
                + ",cache=writeback,aio=threads,discard=unmap");
        add(a, "-device", "virtio-blk-pci,drive=hd0,bootindex=1");

        if (!VmConfig.isEmpty(c.isoPath)) {
            add(a, "-drive", "file=" + escapeOpt(c.isoPath) + ",if=none,id=cd0,media=cdrom,readonly=on");
            if (c.arch == GuestArch.X86_64) {
                add(a, "-device", "ide-cd,drive=cd0,bootindex=0");
            } else {
                add(a, "-device", "virtio-scsi-pci,id=scsi0");
                add(a, "-device", "scsi-cd,bus=scsi0.0,drive=cd0,bootindex=0");
            }
        }

        add(a, "-netdev", "user,id=net0,hostfwd=tcp:127.0.0.1:" + env.adbHostPort + "-:" + c.guestAdbPort);
        add(a, "-device", "virtio-net-pci,netdev=net0");

        add(a, "-device", c.effectiveDisplayDevice());
        add(a, "-device", "qemu-xhci,id=xhci");
        add(a, "-device", "usb-tablet,bus=xhci.0");
        add(a, "-device", "usb-kbd,bus=xhci.0");
        add(a, "-device", "virtio-rng-pci");

        add(a, "-display", "none");
        add(a, "-vnc", "unix:" + escapeOpt(env.vncSocket));
        add(a, "-qmp", "unix:" + escapeOpt(env.qmpSocket) + ",server=on,wait=off");
        add(a, "-serial", "file:" + escapeOpt(env.serialLog));
        add(a, "-monitor", "none");
        add(a, "-rtc", "base=localtime,clock=host");
        return Collections.unmodifiableList(a);
    }

    /** qcow2 for our overlays, raw for anything else (.img). */
    static String diskFormat(String path) {
        String p = path.toLowerCase();
        return p.endsWith(".qcow2") ? "qcow2" : "raw";
    }

    /** QEMU option values use ',' as separator; a literal comma is written ',,'. */
    static String escapeOpt(String v) {
        return v.replace(",", ",,");
    }

    static String sanitize(String name) {
        return name.replaceAll("[^A-Za-z0-9 _.-]", "_");
    }

    private static void add(List<String> a, String... parts) {
        Collections.addAll(a, parts);
    }
}
