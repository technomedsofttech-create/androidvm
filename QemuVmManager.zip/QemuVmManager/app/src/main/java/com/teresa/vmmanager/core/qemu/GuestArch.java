package com.teresa.vmmanager.core.qemu;

/** Guest CPU architecture. Without root there is no KVM, so both run under TCG emulation. */
public enum GuestArch {
    /** Android-x86 family images (Bliss OS 15 = Android 12L, Bliss OS 16 = Android 13, AOSP x86_64 builds). */
    X86_64("qemu-system-x86_64", "libqemu-system-x86_64.so"),
    /** AOSP arm64 builds made for the QEMU "virt" machine (UEFI or direct kernel boot). */
    AARCH64("qemu-system-aarch64", "libqemu-system-aarch64.so");

    public final String argv0;
    /** File name inside the APK's nativeLibraryDir. */
    public final String libraryName;

    GuestArch(String argv0, String libraryName) {
        this.argv0 = argv0;
        this.libraryName = libraryName;
    }
}
