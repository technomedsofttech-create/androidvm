package com.teresa.vmmanager.ui

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.teresa.vmmanager.VmApp
import com.teresa.vmmanager.core.adb.AdbConnection
import com.teresa.vmmanager.core.adb.GuestPackages
import com.teresa.vmmanager.core.rfb.RfbClient
import com.teresa.vmmanager.runtime.UnixTransport
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * One window per VM (documentLaunchMode keyed on vm://<id>), so several VMs show up as separate
 * entries in Recents. Connects to QEMU's VNC socket, reconnecting while the VM is alive, and
 * optionally launches a guest app once the guest has booted (used by home-screen shortcuts).
 */
class DisplayActivity : ComponentActivity() {
    private lateinit var app: VmApp
    private lateinit var vmId: String
    private lateinit var screen: VmDisplayView
    private lateinit var statusText: TextView
    @Volatile private var closing = false
    private var rfbThread: Thread? = null

    private val adbMutex = Mutex()
    private var adb: AdbConnection? = null
    private var launchJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as VmApp
        vmId = intent.data?.host ?: run { finish(); return }
        val config = runCatching { app.store.load(vmId) }.getOrNull() ?: run { finish(); return }
        @Suppress("DEPRECATION") // TaskDescription.Builder needs API 33; minSdk is 31
        setTaskDescription(android.app.ActivityManager.TaskDescription(config.name))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        screen = VmDisplayView(this)
        statusText = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(0xAA000000.toInt())
            setPadding(24, 12, 24, 12)
            text = "Connecting to ${config.name}…"
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(screen, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(statusText, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            addView(navBar(), FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        }
        setContentView(root)
        startDisplayLoop()
        handleLaunchRequest(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLaunchRequest(intent)
    }

    private fun navBar(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setBackgroundColor(0xCC111111.toInt())
        fun button(label: String, onClick: () -> Unit) = addView(
            Button(context, null, android.R.attr.borderlessButtonStyle).apply {
                text = label
                setTextColor(Color.WHITE)
                setOnClickListener { onClick() }
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f),
        )
        button("Back") { guestKey(KEY_BACK, fallbackKeysym = Keysyms.ESCAPE) }
        button("Home") { guestKey(KEY_HOME) }
        button("Apps") { guestKey(KEY_APP_SWITCH) }
        button("Keyboard") { toggleKeyboard() }
        button("Exit") { finish() }
    }

    // ---- display -------------------------------------------------------------------------

    private fun startDisplayLoop() {
        rfbThread = Thread({
            var announcedWaiting = false
            while (!closing) {
                if (!app.controller.isRunning(vmId)) {
                    setStatus("VM is not running")
                    Thread.sleep(1000)
                    continue
                }
                val socket = app.store.vncSocket(vmId)
                val client = runCatching {
                    RfbClient(UnixTransport(socket), object : RfbClient.Listener {
                        override fun onResize(width: Int, height: Int) = screen.onResize(width, height)
                        override fun onFramebufferUpdate(x: Int, y: Int, w: Int, h: Int) = screen.onFrame()
                        override fun onBell() {}
                    }).also { it.handshake() }
                }.getOrNull()
                if (client == null) {
                    if (!announcedWaiting) setStatus("Waiting for the VM display…")
                    announcedWaiting = true
                    Thread.sleep(500)
                    continue
                }
                screen.client = client
                if (launchJob?.isActive != true) setStatus(null)
                runCatching { client.runLoop() }
                screen.client = null
                runCatching { client.close() }
                if (!closing) setStatus("Display disconnected, reconnecting…")
            }
        }, "rfb-$vmId").also { it.start() }
    }

    private fun setStatus(text: String?) = runOnUiThread {
        statusText.text = text ?: ""
        statusText.visibility = if (text == null) android.view.View.GONE else android.view.View.VISIBLE
    }

    // ---- guest control over adb ------------------------------------------------------------

    private suspend fun adbConnection(onWaiting: () -> Unit = {}): AdbConnection = adbMutex.withLock {
        adb?.let { return@withLock it }
        app.guestAdb.connect(vmId, onWaitingForApproval = onWaiting).also { adb = it }
    }

    private fun guestKey(androidKeyCode: Int, fallbackKeysym: Int? = null) {
        val ready = adb
        if (ready == null) {
            // adb isn't up yet (still booting): best effort through the virtual keyboard.
            fallbackKeysym?.let { screen.tapKeysym(it) }
            lifecycleScope.launch { runCatching { adbConnection() } }
            return
        }
        lifecycleScope.launch {
            runCatching { app.guestAdb.keyEvent(ready, androidKeyCode) }.onFailure { adb = null }
        }
    }

    private fun handleLaunchRequest(intent: Intent) {
        val pkg = intent.getStringExtra(EXTRA_LAUNCH_PACKAGE) ?: return
        if (!GuestPackages.isPackageName(pkg)) return
        intent.removeExtra(EXTRA_LAUNCH_PACKAGE)
        launchJob?.cancel()
        launchJob = lifecycleScope.launch {
            val label = GuestPackages.guessLabel(pkg)
            setStatus("Waiting for Android to boot, then opening $label…")
            try {
                val conn = adbConnection { setStatus("Tap \"Allow\" on the debugging prompt inside the VM") }
                app.guestAdb.launch(conn, pkg)
                setStatus(null)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                setStatus(null)
                Toast.makeText(this@DisplayActivity, "Couldn't open $label: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun toggleKeyboard() {
        screen.requestFocus()
        val imm = getSystemService(InputMethodManager::class.java)
        imm.showSoftInput(screen, InputMethodManager.SHOW_IMPLICIT)
    }

    override fun onDestroy() {
        closing = true
        runCatching { screen.client?.close() }
        screen.release()
        runCatching { adb?.close() }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_LAUNCH_PACKAGE = "launchPackage"
        private const val KEY_HOME = 3
        private const val KEY_BACK = 4
        private const val KEY_APP_SWITCH = 187

        fun intent(context: Context, vmId: String, launchPackage: String? = null): Intent =
            Intent(context, DisplayActivity::class.java)
                .setData(Uri.parse("vm://$vmId"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .apply { if (launchPackage != null) putExtra(EXTRA_LAUNCH_PACKAGE, launchPackage) }
    }
}
