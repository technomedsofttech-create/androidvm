package com.teresa.vmmanager.shortcuts

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import com.teresa.vmmanager.VmApp
import com.teresa.vmmanager.core.adb.GuestPackages
import com.teresa.vmmanager.ui.DisplayActivity

/**
 * Trampoline for pinned guest-app shortcuts: validates the shortcut, starts the VM if it isn't
 * running, and opens the VM's display window with the package to launch. The display window
 * waits for the guest to finish booting and then launches the app over adb, so the user watches
 * the boot instead of a spinner.
 */
class ShortcutLaunchActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as VmApp
        val vmId = intent.getStringExtra(GuestShortcuts.EXTRA_VM_ID)
        val pkg = intent.getStringExtra(GuestShortcuts.EXTRA_PACKAGE)
        val config = vmId?.let { runCatching { app.store.load(it) }.getOrNull() }
        when {
            config == null || pkg == null || !GuestPackages.isPackageName(pkg) ->
                Toast.makeText(this, "This shortcut's VM no longer exists", Toast.LENGTH_LONG).show()
            else -> try {
                app.controller.start(config.id) // no-op if already running
                startActivity(DisplayActivity.intent(this, config.id, launchPackage = pkg))
            } catch (e: Exception) {
                Toast.makeText(this, "Couldn't start ${config.name}: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        finish()
    }
}
