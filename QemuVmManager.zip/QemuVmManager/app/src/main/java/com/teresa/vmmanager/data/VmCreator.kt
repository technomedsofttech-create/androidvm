package com.teresa.vmmanager.data

import android.net.Uri
import com.teresa.vmmanager.core.qemu.DiskImages
import com.teresa.vmmanager.core.qemu.GuestArch
import com.teresa.vmmanager.core.qemu.GuestProfile
import com.teresa.vmmanager.core.qemu.VmConfig
import com.teresa.vmmanager.runtime.VmController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Builds a new, independent VM from a user-picked image. */
class VmCreator(
    private val store: VmStore,
    private val importer: ImageImporter,
    private val controller: VmController,
) {
    data class Request(
        val name: String,
        val profile: GuestProfile,
        val arch: GuestArch,
        val ramMb: Int,
        val cpus: Int,
        val diskGb: Int,
        val image: Uri,
    )

    /**
     * - qcow2/raw disk image -> imported once into images/, then a per-VM qcow2 overlay on top
     *   (so several VMs can share one 4-8 GB base without copying it)
     * - ISO -> a blank per-VM qcow2 of [Request.diskGb] plus the ISO as a CD-ROM to install from
     */
    suspend fun create(req: Request, onProgress: (String) -> Unit): VmConfig {
        val imported = importer.import(req.image) { copied, total ->
            val pct = if (total > 0) " ${copied * 100 / total}%" else " ${copied shr 20} MB"
            onProgress("Importing image…$pct")
        }
        val id = store.newId()
        val dir = store.vmDir(id).apply { mkdirs() }
        try {
            val disk = File(dir, "disk.qcow2")
            val config = VmConfig().apply {
                this.id = id
                name = req.name.trim().ifEmpty { req.profile.label }
                profile = req.profile
                arch = req.arch
                ramMb = req.ramMb
                cpus = req.cpus
                diskPath = disk.absolutePath
            }
            withContext(Dispatchers.IO) {
                when (imported.kind) {
                    DiskImages.Kind.ISO -> {
                        onProgress("Creating ${req.diskGb} GB disk…")
                        controller.createBlankDisk(disk, req.diskGb)
                        config.isoPath = imported.file.absolutePath
                    }
                    else -> {
                        onProgress("Creating copy-on-write disk…")
                        controller.createOverlay(imported.file, imported.kind, disk)
                    }
                }
                store.save(config)
            }
            return config
        } catch (e: Exception) {
            dir.deleteRecursively()
            throw e
        }
    }
}
