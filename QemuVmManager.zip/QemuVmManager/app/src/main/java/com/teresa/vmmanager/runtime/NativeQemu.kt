package com.teresa.vmmanager.runtime

import java.io.File

/** JNI bridge to app/src/main/cpp/qemu_host.c. */
object NativeQemu {
    init {
        System.loadLibrary("qemuhost")
    }

    /**
     * Loads [library] and runs QEMU's main() on the calling thread until the VM exits.
     * Must only be called once per process.
     */
    fun run(library: File, argv: List<String>, log: File, tmpDir: File): Int =
        nativeRun(library.absolutePath, argv.toTypedArray(), log.absolutePath, tmpDir.absolutePath)

    @JvmStatic
    private external fun nativeRun(library: String, argv: Array<String>, logPath: String, tmpDir: String): Int
}
