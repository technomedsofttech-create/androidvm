package com.teresa.vmmanager.core.qemu;

import java.util.ArrayList;
import java.util.List;

/**
 * Everything QEMU needs to know about one VM. Plain mutable fields so the Android layer can
 * (de)serialize it with org.json; {@link #validate()} is the single gate before launch.
 */
public final class VmConfig {
    public String id;
    public String name;
    public GuestProfile profile = GuestProfile.ANDROID_13;
    public GuestArch arch = GuestArch.X86_64;

    public int ramMb = 4096;
    public int cpus = 4;
    /** TCG translation-cache size. Bigger = fewer retranslations, costs host RAM. */
    public int tbSizeMb = 256;

    /** Per-VM writable disk (usually a qcow2 overlay on top of a shared base image). */
    public String diskPath;
    /** Optional installer/live ISO attached as a CD-ROM. */
    public String isoPath;
    /** Optional direct kernel boot. When set, initrdPath and cmdline are used too. */
    public String kernelPath;
    public String initrdPath;
    public String cmdline;
    /** Optional UEFI firmware for aarch64 guests (edk2-aarch64-code.fd). */
    public String firmwarePath;

    /** Guest port adbd listens on (Android-x86 builds commonly use 5555). */
    public int guestAdbPort = 5555;

    /** "virtio-vga" (x86 default), "VGA", "virtio-gpu-pci" (arm default) or "ramfb". */
    public String displayDevice;

    public List<String> validate() {
        List<String> errors = new ArrayList<>();
        if (id == null || !id.matches("[a-z0-9]{4,16}")) errors.add("id must be 4-16 lowercase letters/digits");
        if (name == null || name.trim().isEmpty()) errors.add("name is required");
        if (ramMb < 1024 || ramMb > 16384) errors.add("RAM must be between 1024 and 16384 MB");
        if (cpus < 1 || cpus > 8) errors.add("CPUs must be between 1 and 8");
        if (tbSizeMb < 32 || tbSizeMb > 2048) errors.add("TB cache must be between 32 and 2048 MB");
        if (diskPath == null || diskPath.isEmpty()) errors.add("a disk is required");
        if (kernelPath != null && !kernelPath.isEmpty() && (initrdPath == null || initrdPath.isEmpty()))
            errors.add("direct kernel boot needs an initrd");
        if (guestAdbPort < 1 || guestAdbPort > 65535) errors.add("guest adb port is invalid");
        if (displayDevice != null && !displayDevice.matches("[A-Za-z0-9-]+"))
            errors.add("display device name is invalid");
        if (arch == GuestArch.AARCH64 && isEmpty(kernelPath) && isEmpty(firmwarePath))
            errors.add("aarch64 guests need UEFI firmware or a kernel");
        return errors;
    }

    public String effectiveDisplayDevice() {
        if (!isEmpty(displayDevice)) return displayDevice;
        return arch == GuestArch.X86_64 ? "virtio-vga" : "virtio-gpu-pci";
    }

    public String effectiveCmdline() {
        if (!isEmpty(cmdline)) return cmdline;
        return arch == GuestArch.X86_64 ? profile.defaultX86Cmdline() : profile.defaultArmCmdline();
    }

    static boolean isEmpty(String s) {
        return s == null || s.isEmpty();
    }
}
