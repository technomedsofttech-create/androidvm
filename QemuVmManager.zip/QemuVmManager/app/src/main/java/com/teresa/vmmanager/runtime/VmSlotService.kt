package com.teresa.vmmanager.runtime

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Process
import android.util.Log
import com.teresa.vmmanager.R
import com.teresa.vmmanager.VmApp
import com.teresa.vmmanager.core.qemu.GuestArch
import com.teresa.vmmanager.core.qemu.QemuCommandBuilder
import com.teresa.vmmanager.core.qemu.RuntimeEnv
import com.teresa.vmmanager.core.qmp.QmpClient
import com.teresa.vmmanager.data.VmStore
import com.teresa.vmmanager.ui.DisplayActivity
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Hosts exactly one VM in its own process (see android:process in the manifest).
 * Subclasses only pin the slot index; Android needs a distinct component per process.
 */
abstract class VmSlotService : Service() {
    protected abstract val slotIndex: Int

    private lateinit var store: VmStore
    private lateinit var registry: SlotRegistry
    private var vmId: String? = null
    private var qemuThread: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val control = Executors.newSingleThreadScheduledExecutor()

    override fun onCreate() {
        super.onCreate()
        store = VmStore(this)
        registry = SlotRegistry(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> intent.getStringExtra(EXTRA_VM_ID)?.let { start(it) }
            ACTION_STOP -> control.execute { gracefulStop() }
            ACTION_KILL -> control.execute { qmp { it.quit() } }
            null -> stopSelf() // restarted by the system after our process died: nothing to resume
        }
        // QEMU state can't survive a process death, so never ask Android to recreate us.
        return START_NOT_STICKY
    }

    private fun start(id: String) {
        if (qemuThread != null) {
            // Every startForegroundService() must be answered with startForeground(), even a duplicate.
            startForegroundCompat(buildNotification(vmId ?: id, "Running"))
            Log.w(TAG, "slot $slotIndex already runs $vmId, ignoring start of $id")
            return
        }
        vmId = id
        // Go foreground before anything can fail, or Android kills us for missing the deadline.
        startForegroundCompat(buildNotification(id, "Starting…"))
        val config = runCatching { store.load(id) }.getOrElse {
            fail(id, "cannot read VM config: ${it.message}")
            return
        }
        notifyUpdate(config.name, "Starting…")
        registry.write(SlotRegistry.Slot(slotIndex, id, Process.myPid(), SlotRegistry.State.STARTING, null))

        val binaries = QemuBinaries(this)
        val library = binaries.qemuLibrary(config.arch)
        if (!library.isFile) {
            fail(id, "QEMU for ${config.arch} is not bundled in this build (${library.name} missing)")
            return
        }
        if (config.arch == GuestArch.AARCH64 && config.kernelPath.isNullOrEmpty() && config.firmwarePath.isNullOrEmpty()) {
            config.firmwarePath = binaries.edk2Aarch64().absolutePath
        }

        listOf(store.qmpSocket(id), store.vncSocket(id)).forEach { it.delete() }
        val env = RuntimeEnv(
            binaries.dataDir().absolutePath,
            store.qmpSocket(id).absolutePath,
            store.vncSocket(id).absolutePath,
            store.serialLog(id).absolutePath,
            SlotRegistry.adbPort(slotIndex),
        )
        val argv = runCatching { QemuCommandBuilder.build(config, env) }.getOrElse {
            fail(id, it.message ?: "invalid configuration")
            return
        }
        val log = store.qemuLog(id)
        rotate(log)
        log.appendText("argv: ${argv.joinToString(" ")}\n")

        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vmmanager:vm$slotIndex")
            .apply { setReferenceCounted(false); acquire() }

        val mode = LaunchMode.current(this)
        // 64 MB stack: QEMU's main loop and coroutines expect a desktop-sized main-thread stack.
        qemuThread = Thread(null, {
            val exit = try {
                when (mode) {
                    LaunchMode.IN_PROCESS -> NativeQemu.run(library, argv, log, cacheDir)
                    LaunchMode.CHILD_PROCESS -> runAsChild(library, argv, log)
                }
            } catch (t: Throwable) {
                log.appendText("launcher error: $t\n")
                -1
            }
            onQemuExited(id, exit, log)
        }, "qemu-main-$slotIndex", 64L shl 20).also { it.start() }

        control.schedule({ watchUntilRunning(id, config.name) }, 500, TimeUnit.MILLISECONDS)
    }

    /** Child-process fallback: works where the in-process library isn't available, but is
     *  subject to the phantom-process killer (see README). */
    private fun runAsChild(library: File, argv: List<String>, log: File): Int {
        val pb = ProcessBuilder(listOf(library.absolutePath) + argv.drop(1))
        pb.environment()["LD_LIBRARY_PATH"] = QemuBinaries(this).nativeLibraryDir.absolutePath
        pb.environment()["TMPDIR"] = cacheDir.absolutePath
        pb.environment()["HOME"] = cacheDir.absolutePath
        pb.redirectErrorStream(true)
        pb.redirectOutput(ProcessBuilder.Redirect.appendTo(log))
        return pb.start().waitFor()
    }

    private fun watchUntilRunning(id: String, name: String) {
        repeat(120) {
            val status = runCatching { QmpClient.connect(UnixTransport(store.qmpSocket(id)), 3000).use { it.status() } }
            if (status.isSuccess) {
                registry.write(SlotRegistry.Slot(slotIndex, id, Process.myPid(), SlotRegistry.State.RUNNING, status.getOrNull()))
                notifyUpdate(name, "Running")
                return
            }
            if (qemuThread?.isAlive != true) return
            Thread.sleep(500)
        }
    }

    private fun gracefulStop() {
        val id = vmId ?: return stopSelf()
        registry.write(SlotRegistry.Slot(slotIndex, id, Process.myPid(), SlotRegistry.State.STOPPING, null))
        qmp { it.powerdown() }
        // Android may ignore the ACPI button (e.g. stuck on boot); quit QEMU after a grace period.
        control.schedule({ qmp { it.quit() } }, POWERDOWN_GRACE_SECONDS, TimeUnit.SECONDS)
    }

    private fun qmp(block: (QmpClient) -> Unit) {
        val id = vmId ?: return
        runCatching { QmpClient.connect(UnixTransport(store.qmpSocket(id)), 3000).use(block) }
            .onFailure { Log.w(TAG, "QMP command failed: $it") }
    }

    private fun onQemuExited(id: String, exit: Int, log: File) {
        val state = if (exit == 0) SlotRegistry.State.STOPPED else SlotRegistry.State.FAILED
        val message = if (exit == 0) null else "QEMU exited with $exit: ${lastLines(log)}"
        registry.write(SlotRegistry.Slot(slotIndex, id, Process.myPid(), state, message))
        listOf(store.qmpSocket(id), store.vncSocket(id)).forEach { it.delete() }
        wakeLock?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        // QEMU's globals can't be re-initialised: this process must not host another VM.
        Process.killProcess(Process.myPid())
    }

    private fun fail(id: String, message: String) {
        Log.e(TAG, message)
        registry.write(SlotRegistry.Slot(slotIndex, id, Process.myPid(), SlotRegistry.State.FAILED, message))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startForegroundCompat(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_BASE + slotIndex, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_BASE + slotIndex, n)
        }
    }

    private fun notifyUpdate(name: String, text: String) {
        getSystemService(android.app.NotificationManager::class.java)
            .notify(NOTIFICATION_BASE + slotIndex, buildNotification(name, text))
    }

    private fun buildNotification(name: String, text: String): Notification {
        val id = vmId!!
        val open = PendingIntent.getActivity(
            this, slotIndex, DisplayActivity.intent(this, id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 100 + slotIndex, Intent(this, javaClass).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return Notification.Builder(this, VmApp.CHANNEL_VMS)
            .setSmallIcon(R.drawable.ic_stat_vm)
            .setContentTitle(name)
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Shut down", stop).build())
            .build()
    }

    private fun rotate(log: File) {
        if (log.length() > 2L shl 20) log.renameTo(File(log.parentFile, log.name + ".1"))
    }

    private fun lastLines(log: File): String =
        runCatching { log.readLines().takeLast(4).joinToString(" | ") }.getOrDefault("")

    override fun onDestroy() {
        control.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "VmSlotService"
        const val ACTION_START = "com.teresa.vmmanager.START"
        const val ACTION_STOP = "com.teresa.vmmanager.STOP"
        const val ACTION_KILL = "com.teresa.vmmanager.KILL"
        const val EXTRA_VM_ID = "vmId"
        private const val NOTIFICATION_BASE = 4200
        private const val POWERDOWN_GRACE_SECONDS = 45L

        fun serviceClass(slot: Int): Class<out VmSlotService> = when (slot) {
            0 -> VmSlot0Service::class.java
            1 -> VmSlot1Service::class.java
            2 -> VmSlot2Service::class.java
            3 -> VmSlot3Service::class.java
            else -> throw IllegalArgumentException("slot $slot")
        }
    }
}

class VmSlot0Service : VmSlotService() { override val slotIndex = 0 }
class VmSlot1Service : VmSlotService() { override val slotIndex = 1 }
class VmSlot2Service : VmSlotService() { override val slotIndex = 2 }
class VmSlot3Service : VmSlotService() { override val slotIndex = 3 }

enum class LaunchMode {
    /** QEMU loaded with dlopen into the slot process (default; immune to the phantom-process killer). */
    IN_PROCESS,
    /** QEMU exec'd as a child process (fallback for builds that only ship executables). */
    CHILD_PROCESS;

    companion object {
        private const val PREFS = "settings"
        private const val KEY = "launch_mode"

        fun current(context: Context): LaunchMode =
            runCatching {
                valueOf(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, IN_PROCESS.name)!!)
            }.getOrDefault(IN_PROCESS)

        fun set(context: Context, mode: LaunchMode) =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, mode.name).apply()
    }
}
