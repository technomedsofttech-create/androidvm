package com.teresa.vmmanager.core.qmp;

import com.teresa.vmmanager.core.io.Transport;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * QEMU Machine Protocol client. QEMU sends one JSON object per line; asynchronous events
 * ({"event": ...}) are skipped while waiting for a command's reply. Replies are returned as
 * raw JSON strings so this class needs no JSON library.
 */
public final class QmpClient implements Closeable {
    private final Transport transport;
    private final BufferedReader in;
    private final OutputStream out;

    private QmpClient(Transport t) throws IOException {
        this.transport = t;
        this.in = new BufferedReader(new InputStreamReader(t.input(), StandardCharsets.UTF_8));
        this.out = t.output();
    }

    public static QmpClient connect(Transport t, int timeoutMs) throws IOException {
        QmpClient c = new QmpClient(t);
        boolean ok = false;
        try {
            t.setReadTimeout(timeoutMs);
            String greeting = c.readLine();
            if (!greeting.contains("\"QMP\"")) throw new IOException("not a QMP greeting: " + greeting);
            c.execute("qmp_capabilities");
            ok = true;
            return c;
        } finally {
            if (!ok) c.close();
        }
    }

    /** Executes a command without arguments; throws on a QMP error reply. */
    public synchronized String execute(String command) throws IOException {
        return executeRaw("{\"execute\":\"" + command + "\"}");
    }

    public synchronized String executeRaw(String json) throws IOException {
        out.write((json + "\n").getBytes(StandardCharsets.UTF_8));
        out.flush();
        while (true) {
            String line = readLine();
            if (line.contains("\"event\"")) continue;
            if (line.contains("\"error\"")) throw new IOException("QMP error: " + line);
            if (line.contains("\"return\"")) return line;
        }
    }

    /** ACPI power button: Android shows its power menu / shuts down cleanly. */
    public void powerdown() throws IOException {
        execute("system_powerdown");
    }

    /** Immediate QEMU exit; the guest is not shut down cleanly. */
    public void quit() throws IOException {
        try {
            execute("quit");
        } catch (IOException ignored) {
            // QEMU often closes the socket before the reply is read.
        }
    }

    public void pause() throws IOException {
        execute("stop");
    }

    public void resume() throws IOException {
        execute("cont");
    }

    /** Returns e.g. "running", "paused", "shutdown". */
    public String status() throws IOException {
        String reply = execute("query-status");
        int i = reply.indexOf("\"status\"");
        if (i < 0) return "unknown";
        int start = reply.indexOf('"', reply.indexOf(':', i) + 1) + 1;
        int end = reply.indexOf('"', start);
        return start > 0 && end > start ? reply.substring(start, end) : "unknown";
    }

    private String readLine() throws IOException {
        String line = in.readLine();
        if (line == null) throw new IOException("QMP socket closed");
        return line;
    }

    @Override
    public void close() throws IOException {
        transport.close();
    }
}
