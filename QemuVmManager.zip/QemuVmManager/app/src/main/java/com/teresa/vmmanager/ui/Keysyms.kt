package com.teresa.vmmanager.ui

import android.view.KeyEvent

/** Android key codes / characters -> X11 keysyms, as QEMU's VNC server expects (en-us keymap). */
object Keysyms {
    const val BACKSPACE = 0xff08
    const val TAB = 0xff09
    const val RETURN = 0xff0d
    const val ESCAPE = 0xff1b
    const val DELETE = 0xffff
    const val SHIFT_L = 0xffe1

    private val special = mapOf(
        KeyEvent.KEYCODE_DEL to BACKSPACE,
        KeyEvent.KEYCODE_FORWARD_DEL to DELETE,
        KeyEvent.KEYCODE_ENTER to RETURN,
        KeyEvent.KEYCODE_NUMPAD_ENTER to RETURN,
        KeyEvent.KEYCODE_TAB to TAB,
        KeyEvent.KEYCODE_ESCAPE to ESCAPE,
        KeyEvent.KEYCODE_DPAD_LEFT to 0xff51,
        KeyEvent.KEYCODE_DPAD_UP to 0xff52,
        KeyEvent.KEYCODE_DPAD_RIGHT to 0xff53,
        KeyEvent.KEYCODE_DPAD_DOWN to 0xff54,
        KeyEvent.KEYCODE_MOVE_HOME to 0xff50,
        KeyEvent.KEYCODE_MOVE_END to 0xff57,
        KeyEvent.KEYCODE_PAGE_UP to 0xff55,
        KeyEvent.KEYCODE_PAGE_DOWN to 0xff56,
        KeyEvent.KEYCODE_INSERT to 0xff63,
        KeyEvent.KEYCODE_SHIFT_LEFT to SHIFT_L,
        KeyEvent.KEYCODE_SHIFT_RIGHT to 0xffe2,
        KeyEvent.KEYCODE_CTRL_LEFT to 0xffe3,
        KeyEvent.KEYCODE_CTRL_RIGHT to 0xffe4,
        KeyEvent.KEYCODE_ALT_LEFT to 0xffe9,
        KeyEvent.KEYCODE_ALT_RIGHT to 0xffea,
        KeyEvent.KEYCODE_META_LEFT to 0xffeb,
        KeyEvent.KEYCODE_META_RIGHT to 0xffec,
        KeyEvent.KEYCODE_SPACE to 0x20,
    ) + (0..11).associate { (KeyEvent.KEYCODE_F1 + it) to (0xffbe + it) }

    /** Hardware/IME key event -> keysym, or null when there's no sensible mapping. */
    fun fromKeyEvent(event: KeyEvent): Int? {
        special[event.keyCode]?.let { return it }
        val ch = event.getUnicodeChar(event.metaState and KeyEvent.META_SHIFT_MASK.inv())
        return if (ch > 0) fromChar(ch.toChar()) else null
    }

    /** Character -> keysym. Latin-1 maps directly; other Unicode uses the 0x01000000 range. */
    fun fromChar(c: Char): Int = when (c) {
        '\n' -> RETURN
        '\t' -> TAB
        '\b' -> BACKSPACE
        else -> if (c.code < 0x100) c.code else 0x01000000 or c.code
    }

    private const val SHIFTED_US = "~!@#$%^&*()_+{}|:\"<>?"

    /** True when typing [c] on a US keyboard needs Shift held (QEMU maps keysyms to scancodes). */
    fun needsShift(c: Char): Boolean = c in 'A'..'Z' || c in SHIFTED_US
}
