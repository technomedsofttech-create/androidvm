package com.teresa.vmmanager.core.qemu;

/** Per-launch values that depend on the slot the VM runs in, not on the VM itself. */
public final class RuntimeEnv {
    /** Directory with BIOS/option ROMs/keymaps (QEMU's -L). */
    public final String qemuDataDir;
    public final String qmpSocket;
    public final String vncSocket;
    public final String serialLog;
    /** Host loopback port forwarded to the guest's adbd. Unique per running slot. */
    public final int adbHostPort;

    public RuntimeEnv(String qemuDataDir, String qmpSocket, String vncSocket, String serialLog, int adbHostPort) {
        this.qemuDataDir = qemuDataDir;
        this.qmpSocket = qmpSocket;
        this.vncSocket = vncSocket;
        this.serialLog = serialLog;
        this.adbHostPort = adbHostPort;
    }
}
