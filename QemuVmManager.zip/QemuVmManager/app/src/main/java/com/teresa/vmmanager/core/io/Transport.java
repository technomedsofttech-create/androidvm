package com.teresa.vmmanager.core.io;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * A connected byte stream (unix socket, TCP socket, ...). The protocol clients in
 * {@code core} only depend on this, so they run unchanged on Android and in JVM tests.
 */
public interface Transport extends Closeable {
    InputStream input() throws IOException;

    OutputStream output() throws IOException;

    /** Read timeout in milliseconds, 0 = infinite. Transports that can't time out may ignore it. */
    default void setReadTimeout(int millis) throws IOException {
    }
}
