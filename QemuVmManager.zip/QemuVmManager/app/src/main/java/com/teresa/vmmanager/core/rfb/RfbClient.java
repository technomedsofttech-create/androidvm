package com.teresa.vmmanager.core.rfb;

import com.teresa.vmmanager.core.io.Transport;
import com.teresa.vmmanager.core.io.Wire;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

/**
 * VNC (RFB 3.3/3.8) client for QEMU's built-in VNC server on a private unix socket.
 * Security type None only — the socket lives in the app's private directory, so the
 * filesystem permission is the access control.
 *
 * Pixel format is requested as 32bpp little-endian 0x00RRGGBB, which maps directly onto
 * Android's ARGB_8888 int pixels after OR-ing in opaque alpha.
 */
public final class RfbClient implements Closeable {

    public interface Listener {
        void onResize(int width, int height);

        /** Called on the reader thread after a rectangle batch; read pixels via {@link #copyFramebuffer}. */
        void onFramebufferUpdate(int x, int y, int w, int h);

        void onBell();
    }

    public static final int ENC_RAW = 0;
    public static final int ENC_COPYRECT = 1;
    public static final int ENC_DESKTOP_SIZE = -223;

    public static final int BUTTON_LEFT = 1;
    public static final int BUTTON_MIDDLE = 2;
    public static final int BUTTON_RIGHT = 4;
    public static final int WHEEL_UP = 8;
    public static final int WHEEL_DOWN = 16;

    private final Transport transport;
    private final DataInputStream in;
    private final OutputStream out;
    private final Listener listener;
    private final Object fbLock = new Object();

    private int width, height;
    private int[] fb = new int[0];
    private String desktopName = "";
    private byte[] rowScratch = new byte[0];
    private volatile boolean running;

    public RfbClient(Transport transport, Listener listener) throws IOException {
        this.transport = transport;
        this.in = new DataInputStream(new BufferedInputStream(transport.input(), 1 << 16));
        this.out = new BufferedOutputStream(transport.output(), 1 << 12);
        this.listener = listener;
    }

    public void handshake() throws IOException {
        String server = new String(Wire.readFully(in, 12), StandardCharsets.US_ASCII);
        if (!server.startsWith("RFB ")) throw new IOException("not an RFB server: " + server.trim());
        int minor = Integer.parseInt(server.substring(8, 11));
        boolean v38 = minor >= 8;
        out.write((v38 ? "RFB 003.008\n" : "RFB 003.003\n").getBytes(StandardCharsets.US_ASCII));
        out.flush();

        if (v38) {
            int n = in.readUnsignedByte();
            if (n == 0) throw new IOException("server refused: " + readReason());
            boolean hasNone = false;
            for (int i = 0; i < n; i++) if (in.readUnsignedByte() == 1) hasNone = true;
            if (!hasNone) throw new IOException("server requires authentication; start QEMU with plain -vnc");
            out.write(1);
            out.flush();
            if (in.readInt() != 0) throw new IOException("security handshake failed: " + readReason());
        } else {
            int type = in.readInt();
            if (type == 0) throw new IOException("server refused: " + readReason());
            if (type != 1) throw new IOException("unsupported security type " + type);
        }

        out.write(1); // ClientInit: shared session, so the display can reconnect without kicking QEMU.
        out.flush();

        int w = in.readUnsignedShort(), h = in.readUnsignedShort();
        Wire.skip(in, 16); // server pixel format; we override it below
        int nameLen = in.readInt();
        desktopName = new String(Wire.readFully(in, nameLen), StandardCharsets.UTF_8);
        resize(w, h);

        writePixelFormat();
        writeEncodings(ENC_RAW, ENC_COPYRECT, ENC_DESKTOP_SIZE);
        requestUpdate(false);
    }

    /** Blocks, processing server messages until the connection closes or {@link #close()} is called. */
    public void runLoop() throws IOException {
        running = true;
        while (running) {
            int type = in.readUnsignedByte();
            switch (type) {
                case 0:
                    readFramebufferUpdate();
                    requestUpdate(true);
                    break;
                case 1: { // SetColourMapEntries (not used for true colour)
                    in.readUnsignedByte();
                    in.readUnsignedShort();
                    int n = in.readUnsignedShort();
                    Wire.skip(in, n * 6L);
                    break;
                }
                case 2:
                    listener.onBell();
                    break;
                case 3: { // ServerCutText
                    Wire.skip(in, 3);
                    int len = in.readInt();
                    Wire.skip(in, len);
                    break;
                }
                default:
                    throw new IOException("unknown RFB server message " + type);
            }
        }
    }

    private void readFramebufferUpdate() throws IOException {
        in.readUnsignedByte();
        int rects = in.readUnsignedShort();
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = 0, maxY = 0;
        for (int i = 0; i < rects; i++) {
            int x = in.readUnsignedShort(), y = in.readUnsignedShort();
            int w = in.readUnsignedShort(), h = in.readUnsignedShort();
            int enc = in.readInt();
            switch (enc) {
                case ENC_RAW:
                    readRaw(x, y, w, h);
                    break;
                case ENC_COPYRECT:
                    copyRect(in.readUnsignedShort(), in.readUnsignedShort(), x, y, w, h);
                    break;
                case ENC_DESKTOP_SIZE:
                    resize(w, h);
                    minX = 0; minY = 0; maxX = w; maxY = h;
                    continue;
                default:
                    throw new IOException("server sent unrequested encoding " + enc);
            }
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x + w);
            maxY = Math.max(maxY, y + h);
        }
        if (maxX > minX && maxY > minY) listener.onFramebufferUpdate(minX, minY, maxX - minX, maxY - minY);
    }

    private void readRaw(int x, int y, int w, int h) throws IOException {
        int rowBytes = w * 4;
        if (rowScratch.length < rowBytes) rowScratch = new byte[rowBytes];
        for (int row = 0; row < h; row++) {
            Wire.readFully(in, rowScratch, 0, rowBytes);
            synchronized (fbLock) {
                if (y + row >= height || x + w > width) continue; // stale rect after a resize
                int dst = (y + row) * width + x;
                for (int col = 0, s = 0; col < w; col++, s += 4) {
                    fb[dst + col] = 0xFF000000
                            | (rowScratch[s + 2] & 0xff) << 16
                            | (rowScratch[s + 1] & 0xff) << 8
                            | (rowScratch[s] & 0xff);
                }
            }
        }
    }

    private void copyRect(int sx, int sy, int dx, int dy, int w, int h) {
        synchronized (fbLock) {
            if (sx + w > width || dx + w > width || sy + h > height || dy + h > height) return;
            if (dy > sy) {
                for (int row = h - 1; row >= 0; row--)
                    System.arraycopy(fb, (sy + row) * width + sx, fb, (dy + row) * width + dx, w);
            } else {
                for (int row = 0; row < h; row++)
                    System.arraycopy(fb, (sy + row) * width + sx, fb, (dy + row) * width + dx, w);
            }
        }
    }

    private void resize(int w, int h) {
        synchronized (fbLock) {
            width = w;
            height = h;
            fb = new int[w * h];
        }
        listener.onResize(w, h);
    }

    /** Copies the current frame into {@code dst} (must hold width*height ints). Returns false on size mismatch. */
    public boolean copyFramebuffer(int[] dst, int expectedWidth, int expectedHeight) {
        synchronized (fbLock) {
            if (expectedWidth != width || expectedHeight != height || dst.length < fb.length) return false;
            System.arraycopy(fb, 0, dst, 0, fb.length);
            return true;
        }
    }

    public int width() {
        synchronized (fbLock) {
            return width;
        }
    }

    public int height() {
        synchronized (fbLock) {
            return height;
        }
    }

    public String desktopName() {
        return desktopName;
    }

    // ---- client -> server --------------------------------------------------------------

    private void writePixelFormat() throws IOException {
        ByteBuffer b = ByteBuffer.allocate(20);
        b.put((byte) 0).put(new byte[3]);
        b.put((byte) 32).put((byte) 24).put((byte) 0).put((byte) 1); // bpp, depth, big-endian=no, true colour
        b.putShort((short) 255).putShort((short) 255).putShort((short) 255);
        b.put((byte) 16).put((byte) 8).put((byte) 0).put(new byte[3]);
        writeAndFlush(b.array());
    }

    private void writeEncodings(int... encodings) throws IOException {
        ByteBuffer b = ByteBuffer.allocate(4 + 4 * encodings.length);
        b.put((byte) 2).put((byte) 0).putShort((short) encodings.length);
        for (int e : encodings) b.putInt(e);
        writeAndFlush(b.array());
    }

    public void requestUpdate(boolean incremental) throws IOException {
        int w, h;
        synchronized (fbLock) {
            w = width;
            h = height;
        }
        ByteBuffer b = ByteBuffer.allocate(10);
        b.put((byte) 3).put((byte) (incremental ? 1 : 0)).putShort((short) 0).putShort((short) 0)
                .putShort((short) w).putShort((short) h);
        writeAndFlush(b.array());
    }

    public void sendPointer(int x, int y, int buttonMask) throws IOException {
        ByteBuffer b = ByteBuffer.allocate(6);
        b.put((byte) 5).put((byte) buttonMask).putShort((short) clamp(x, width())).putShort((short) clamp(y, height()));
        writeAndFlush(b.array());
    }

    public void sendKey(int keysym, boolean down) throws IOException {
        ByteBuffer b = ByteBuffer.allocate(8);
        b.put((byte) 4).put((byte) (down ? 1 : 0)).putShort((short) 0).putInt(keysym);
        writeAndFlush(b.array());
    }

    /** Press and release, for buttons like Back/Home on the toolbar. */
    public void tapKey(int keysym) throws IOException {
        sendKey(keysym, true);
        sendKey(keysym, false);
    }

    private static int clamp(int v, int size) {
        return Math.max(0, Math.min(v, Math.max(0, size - 1)));
    }

    private void writeAndFlush(byte[] data) throws IOException {
        synchronized (out) {
            out.write(data);
            out.flush();
        }
    }

    private String readReason() throws IOException {
        int len = in.readInt();
        return new String(Wire.readFully(in, Math.min(len, 4096)), StandardCharsets.UTF_8);
    }

    @Override
    public void close() throws IOException {
        running = false;
        transport.close();
    }
}
