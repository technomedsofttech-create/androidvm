package com.teresa.vmmanager.runtime

import android.net.LocalSocket
import android.net.LocalSocketAddress
import com.teresa.vmmanager.core.io.Transport
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Unix-domain socket in the app's private directory (QEMU's VNC and QMP endpoints). */
class UnixTransport(path: File) : Transport {
    private val socket = LocalSocket()

    init {
        try {
            socket.connect(LocalSocketAddress(path.absolutePath, LocalSocketAddress.Namespace.FILESYSTEM))
        } catch (e: IOException) {
            socket.close()
            throw e
        }
    }

    override fun input(): InputStream = socket.inputStream
    override fun output(): OutputStream = socket.outputStream
    override fun setReadTimeout(millis: Int) {
        socket.soTimeout = millis
    }

    override fun close() = socket.close()
}

/** TCP to 127.0.0.1 (the slirp host-forward to the guest's adbd). */
class TcpTransport(port: Int, connectTimeoutMs: Int = 3000) : Transport {
    private val socket = Socket()

    init {
        try {
            socket.tcpNoDelay = true
            socket.connect(InetSocketAddress("127.0.0.1", port), connectTimeoutMs)
        } catch (e: IOException) {
            socket.close()
            throw e
        }
    }

    override fun input(): InputStream = socket.getInputStream()
    override fun output(): OutputStream = socket.getOutputStream()
    override fun setReadTimeout(millis: Int) {
        socket.soTimeout = millis
    }

    override fun close() = socket.close()
}
