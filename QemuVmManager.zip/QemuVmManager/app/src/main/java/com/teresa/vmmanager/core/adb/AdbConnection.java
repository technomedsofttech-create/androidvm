package com.teresa.vmmanager.core.adb;

import com.teresa.vmmanager.core.io.Transport;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;

/**
 * Minimal ADB host-side client talking straight to the guest's adbd (no adb server, no
 * external binary). Streams are used one at a time, which is all the manager needs:
 * run a command, install an APK, launch an app.
 */
public final class AdbConnection implements Closeable {

    public interface AuthListener {
        /** Guest is showing "Allow USB debugging?" — tell the user to accept it in the VM window. */
        void onWaitingForApproval();
    }

    public interface ProgressListener {
        void onProgress(long sent, long total);
    }

    private final Transport transport;
    private final InputStream in;
    private final OutputStream out;
    private int maxData = 4096;
    private int nextLocalId = 1;
    private String banner = "";

    private AdbConnection(Transport t) throws IOException {
        this.transport = t;
        this.in = t.input();
        this.out = t.output();
    }

    /**
     * Performs CNXN + AUTH. If the guest doesn't know our key yet, sends the public key and
     * waits up to {@code approvalTimeoutMs} for the user to accept the prompt in the guest.
     */
    public static AdbConnection connect(Transport t, AdbKeyPair key, String keyName,
                                        AuthListener listener, int ioTimeoutMs, int approvalTimeoutMs)
            throws IOException, GeneralSecurityException {
        AdbConnection c = new AdbConnection(t);
        boolean ok = false;
        try {
            c.handshake(key, keyName, listener, ioTimeoutMs, approvalTimeoutMs);
            ok = true;
            return c;
        } finally {
            if (!ok) c.close();
        }
    }

    private void handshake(AdbKeyPair key, String keyName, AuthListener listener, int ioTimeoutMs,
                           int approvalTimeoutMs) throws IOException, GeneralSecurityException {
        transport.setReadTimeout(ioTimeoutMs);
        send(AdbMessage.A_CNXN, AdbMessage.VERSION, AdbMessage.MAX_PAYLOAD, "host::\0".getBytes(StandardCharsets.US_ASCII));
        boolean sentSignature = false, sentPublicKey = false;
        while (true) {
            AdbMessage m = AdbMessage.readFrom(in);
            if (m.command == AdbMessage.A_CNXN) {
                maxData = Math.max(1024, Math.min(m.arg1, AdbMessage.MAX_PAYLOAD));
                banner = new String(m.data, StandardCharsets.UTF_8);
                transport.setReadTimeout(ioTimeoutMs);
                return;
            }
            if (m.command != AdbMessage.A_AUTH || m.arg0 != AdbMessage.AUTH_TOKEN)
                throw new IOException("unexpected " + m + " during handshake");
            if (!sentSignature) {
                send(AdbMessage.A_AUTH, AdbMessage.AUTH_SIGNATURE, 0, key.signToken(m.data));
                sentSignature = true;
            } else if (!sentPublicKey) {
                send(AdbMessage.A_AUTH, AdbMessage.AUTH_RSAPUBLICKEY, 0, key.androidPublicKeyPayload(keyName));
                sentPublicKey = true;
                if (listener != null) listener.onWaitingForApproval();
                transport.setReadTimeout(approvalTimeoutMs);
            } else {
                throw new IOException("guest rejected the adb key");
            }
        }
    }

    public String banner() {
        return banner;
    }

    /** Runs {@code cmd} through the guest's exec: service and returns stdout+stderr. */
    public synchronized String exec(String cmd) throws IOException {
        Stream s = open("exec:" + cmd);
        return s.readAll();
    }

    /**
     * Streams an APK into "cmd package install -S size" (Android 7+). Returns the package
     * manager's output; it contains "Success" when the install worked.
     */
    public synchronized String install(InputStream apk, long size, ProgressListener progress) throws IOException {
        if (size <= 0) throw new IOException("APK size unknown");
        Stream s = open("exec:cmd package install -r -S " + size);
        byte[] buf = new byte[maxData];
        long sent = 0;
        while (sent < size) {
            int want = (int) Math.min(buf.length, size - sent);
            int n = apk.read(buf, 0, want);
            if (n < 0) throw new IOException("APK ended early at " + sent + " of " + size + " bytes");
            byte[] chunk = new byte[n];
            System.arraycopy(buf, 0, chunk, 0, n);
            s.write(chunk);
            sent += n;
            if (progress != null) progress.onProgress(sent, size);
        }
        return s.readAll();
    }

    private Stream open(String destination) throws IOException {
        int localId = nextLocalId++;
        send(AdbMessage.A_OPEN, localId, 0, (destination + "\0").getBytes(StandardCharsets.UTF_8));
        while (true) {
            AdbMessage m = AdbMessage.readFrom(in);
            if (m.command == AdbMessage.A_OKAY && m.arg1 == localId) return new Stream(localId, m.arg0);
            if (m.command == AdbMessage.A_CLSE && m.arg1 == localId)
                throw new IOException("guest refused service: " + destination);
            // Anything else belongs to a stream we already closed; ignore it.
        }
    }

    private void send(int cmd, int a0, int a1, byte[] data) throws IOException {
        new AdbMessage(cmd, a0, a1, data).writeTo(out);
    }

    @Override
    public void close() throws IOException {
        transport.close();
    }

    private final class Stream {
        final int localId;
        final int remoteId;
        final ByteArrayOutputStream received = new ByteArrayOutputStream();
        boolean closed;

        Stream(int localId, int remoteId) {
            this.localId = localId;
            this.remoteId = remoteId;
        }

        /** Sends one WRTE and waits for its OKAY (adb's flow control), buffering any output. */
        void write(byte[] chunk) throws IOException {
            send(AdbMessage.A_WRTE, localId, remoteId, chunk);
            while (true) {
                AdbMessage m = AdbMessage.readFrom(in);
                if (m.arg1 != localId) continue;
                if (m.command == AdbMessage.A_OKAY) return;
                if (handleIncoming(m)) throw new IOException("guest closed the stream during upload");
            }
        }

        String readAll() throws IOException {
            while (!closed) {
                AdbMessage m = AdbMessage.readFrom(in);
                if (m.arg1 != localId) continue;
                handleIncoming(m);
            }
            return received.toString("UTF-8");
        }

        /** @return true when the stream is now closed. */
        private boolean handleIncoming(AdbMessage m) throws IOException {
            if (m.command == AdbMessage.A_WRTE) {
                received.write(m.data);
                send(AdbMessage.A_OKAY, localId, remoteId, null);
            } else if (m.command == AdbMessage.A_CLSE) {
                send(AdbMessage.A_CLSE, localId, remoteId, null);
                closed = true;
            }
            return closed;
        }
    }
}
