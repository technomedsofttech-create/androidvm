package com.teresa.vmmanager.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.InputType
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import com.teresa.vmmanager.core.rfb.RfbClient
import java.util.concurrent.Executors

/**
 * Renders the guest framebuffer (letterboxed, aspect preserved) and turns touches and keys into
 * RFB pointer/key events. Touch is sent as an absolute pointer (QEMU usb-tablet), so a tap lands
 * exactly where the finger is. Two-finger vertical drag scrolls (mouse wheel).
 */
class VmDisplayView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    @Volatile
    var client: RfbClient? = null

    private val sender = Executors.newSingleThreadExecutor()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val drawLock = Any()
    private var bitmap: Bitmap? = null
    private var pixels = IntArray(0)
    private var fbWidth = 0
    private var fbHeight = 0
    private val dst = RectF()
    @Volatile
    private var surfaceReady = false

    private var lastScrollY = 0f
    private var scrolling = false

    init {
        holder.addCallback(this)
        isFocusable = true
        isFocusableInTouchMode = true
    }

    // ---- frames (called from the RFB reader thread) --------------------------------------

    fun onResize(w: Int, h: Int) = synchronized(drawLock) {
        fbWidth = w
        fbHeight = h
        pixels = IntArray(w * h)
        bitmap = if (w > 0 && h > 0) Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) else null
    }

    fun onFrame() {
        val c = client ?: return
        synchronized(drawLock) {
            val bmp = bitmap ?: return
            if (!c.copyFramebuffer(pixels, fbWidth, fbHeight)) return
            bmp.setPixels(pixels, 0, fbWidth, 0, 0, fbWidth, fbHeight)
        }
        draw()
    }

    private fun draw() {
        if (!surfaceReady) return
        val canvas = runCatching { holder.lockHardwareCanvas() }.getOrNull() ?: return
        try {
            canvas.drawColor(Color.BLACK)
            synchronized(drawLock) {
                val bmp = bitmap ?: return@synchronized
                val scale = minOf(width.toFloat() / fbWidth, height.toFloat() / fbHeight)
                val w = fbWidth * scale
                val h = fbHeight * scale
                dst.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
                canvas.drawBitmap(bmp, null, dst, paint)
            }
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceReady = true
        draw()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = draw()

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
    }

    // ---- input ---------------------------------------------------------------------------

    private fun send(block: (RfbClient) -> Unit) {
        val c = client ?: return
        sender.execute { runCatching { block(c) } }
    }

    private fun toGuest(x: Float, y: Float): Pair<Int, Int>? {
        if (dst.width() <= 0f || fbWidth == 0) return null
        val gx = ((x - dst.left) / dst.width() * fbWidth).toInt()
        val gy = ((y - dst.top) / dst.height() * fbHeight).toInt()
        return gx to gy
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.pointerCount >= 2) {
            handleScroll(event)
            return true
        }
        val (gx, gy) = toGuest(event.x, event.y) ?: return true
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                requestFocus()
                send { it.sendPointer(gx, gy, RfbClient.BUTTON_LEFT) }
            }
            MotionEvent.ACTION_MOVE -> if (!scrolling) send { it.sendPointer(gx, gy, RfbClient.BUTTON_LEFT) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                scrolling = false
                send { it.sendPointer(gx, gy, 0) }
            }
        }
        return true
    }

    private fun handleScroll(event: MotionEvent) {
        val y = (event.getY(0) + event.getY(1)) / 2f
        val (gx, gy) = toGuest((event.getX(0) + event.getX(1)) / 2f, y) ?: return
        when (event.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> {
                scrolling = true
                lastScrollY = y
                send { it.sendPointer(gx, gy, 0) } // release the left button pressed by the first finger
            }
            MotionEvent.ACTION_MOVE -> {
                val step = 40f * resources.displayMetrics.density
                while (kotlin.math.abs(y - lastScrollY) >= step) {
                    val wheel = if (y > lastScrollY) RfbClient.WHEEL_UP else RfbClient.WHEEL_DOWN
                    lastScrollY += if (y > lastScrollY) step else -step
                    send { it.sendPointer(gx, gy, wheel); it.sendPointer(gx, gy, 0) }
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean = key(event, true) || super.onKeyDown(keyCode, event)
    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean = key(event, false) || super.onKeyUp(keyCode, event)

    private fun key(event: KeyEvent, down: Boolean): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) return false // host Back stays with the activity
        val sym = Keysyms.fromKeyEvent(event) ?: return false
        send { it.sendKey(sym, down) }
        return true
    }

    /** Types text from the soft keyboard, holding Shift where a US layout needs it. */
    fun typeText(text: CharSequence) = send { c ->
        for (ch in text) {
            val shift = Keysyms.needsShift(ch)
            if (shift) c.sendKey(Keysyms.SHIFT_L, true)
            c.tapKey(Keysyms.fromChar(ch))
            if (shift) c.sendKey(Keysyms.SHIFT_L, false)
        }
    }

    fun tapKeysym(sym: Int) = send { it.tapKey(sym) }

    override fun onCheckIsTextEditor() = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        return object : BaseInputConnection(this, false) {
            override fun commitText(text: CharSequence, newCursorPosition: Int): Boolean {
                typeText(text)
                return true
            }

            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                repeat(beforeLength.coerceAtMost(64)) { tapKeysym(Keysyms.BACKSPACE) }
                repeat(afterLength.coerceAtMost(64)) { tapKeysym(Keysyms.DELETE) }
                return true
            }

            override fun sendKeyEvent(event: KeyEvent): Boolean {
                val sym = Keysyms.fromKeyEvent(event) ?: return super.sendKeyEvent(event)
                send { it.sendKey(sym, event.action == KeyEvent.ACTION_DOWN) }
                return true
            }

            override fun performEditorAction(actionCode: Int): Boolean {
                tapKeysym(Keysyms.RETURN)
                return true
            }
        }
    }

    fun release() {
        sender.shutdownNow()
    }
}
