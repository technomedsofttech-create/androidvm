package com.teresa.vmmanager

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.teresa.vmmanager.data.ImageImporter
import com.teresa.vmmanager.data.VmStore
import com.teresa.vmmanager.guest.GuestAdb
import com.teresa.vmmanager.runtime.QemuBinaries
import com.teresa.vmmanager.runtime.VmController

/**
 * Note: this Application class is also created in every ":vmN" slot process. Keep onCreate
 * cheap; the services build only what they need.
 */
class VmApp : Application() {
    val store by lazy { VmStore(this) }
    val controller by lazy { VmController(this, store) }
    val importer by lazy { ImageImporter(this, store) }
    val guestAdb by lazy { GuestAdb(this, store) }
    val binaries by lazy { QemuBinaries(this) }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_VMS, getString(R.string.channel_vm), NotificationManager.IMPORTANCE_LOW)
        )
    }

    companion object {
        const val CHANNEL_VMS = "vms"
    }
}
