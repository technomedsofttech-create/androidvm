package com.teresa.vmmanager.core.qemu;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Image-type detection and qemu-img argument lists. */
public final class DiskImages {
    private DiskImages() {
    }

    public enum Kind { QCOW2, ISO, RAW }

    /** Detects from the first 0x8006 bytes: qcow2 magic at 0, ISO9660 "CD001" at 0x8001. */
    public static Kind detect(InputStream in) throws IOException {
        byte[] head = new byte[0x8006];
        int n = 0;
        while (n < head.length) {
            int r = in.read(head, n, head.length - n);
            if (r < 0) break;
            n += r;
        }
        if (n >= 4 && head[0] == 'Q' && head[1] == 'F' && head[2] == 'I' && (head[3] & 0xff) == 0xFB) return Kind.QCOW2;
        if (n >= 0x8006 && head[0x8001] == 'C' && head[0x8002] == 'D' && head[0x8003] == '0'
                && head[0x8004] == '0' && head[0x8005] == '1') return Kind.ISO;
        return Kind.RAW;
    }

    /** Copy-on-write overlay: many VMs can share one imported base image. */
    public static List<String> createOverlayArgs(String qemuImg, String base, Kind baseKind, String overlay) {
        if (baseKind == Kind.ISO) throw new IllegalArgumentException("an ISO can't be an overlay base");
        List<String> a = new ArrayList<>();
        Collections.addAll(a, qemuImg, "create", "-f", "qcow2",
                "-b", base, "-F", baseKind == Kind.QCOW2 ? "qcow2" : "raw", overlay);
        return a;
    }

    public static List<String> createBlankArgs(String qemuImg, String path, int sizeGb) {
        if (sizeGb < 4 || sizeGb > 256) throw new IllegalArgumentException("disk size must be 4-256 GB");
        List<String> a = new ArrayList<>();
        Collections.addAll(a, qemuImg, "create", "-f", "qcow2", "-o", "cluster_size=65536,lazy_refcounts=on",
                path, sizeGb + "G");
        return a;
    }

    /** Grow an overlay so the guest has room for apps (the base image is untouched). */
    public static List<String> resizeArgs(String qemuImg, String path, int sizeGb) {
        List<String> a = new ArrayList<>();
        Collections.addAll(a, qemuImg, "resize", "-f", "qcow2", path, sizeGb + "G");
        return a;
    }
}
