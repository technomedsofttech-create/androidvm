package com.teresa.vmmanager.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.teresa.vmmanager.core.qemu.DiskImages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * Copies a user-picked image (Storage Access Framework URI) into private storage.
 * QEMU needs a real file path with random access, so content:// URIs can't be used directly.
 * Re-importing a file with the same name and size reuses the existing copy.
 */
class ImageImporter(private val context: Context, private val store: VmStore) {

    data class Imported(val file: File, val kind: DiskImages.Kind)

    suspend fun import(uri: Uri, onProgress: (copied: Long, total: Long) -> Unit): Imported =
        withContext(Dispatchers.IO) {
            val resolver = context.contentResolver
            val (displayName, size) = queryNameAndSize(uri)
            val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "image" }
            val target = File(store.imagesDir, safeName)

            if (!(target.isFile && size > 0 && target.length() == size)) {
                val free = store.imagesDir.usableSpace
                if (size > 0 && size > free - RESERVE_BYTES) {
                    throw IOException("Not enough space: need ${size shr 20} MB, ${free shr 20} MB free")
                }
                val partial = File(store.imagesDir, "$safeName.part")
                resolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "cannot open $displayName" }
                    partial.outputStream().buffered(1 shl 20).use { out ->
                        val buf = ByteArray(1 shl 20)
                        var copied = 0L
                        while (true) {
                            ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            copied += n
                            onProgress(copied, size)
                        }
                    }
                }
                if (!partial.renameTo(target)) throw IOException("could not finalize $safeName")
            }
            val kind = target.inputStream().use { DiskImages.detect(it) }
            Imported(target, kind)
        }

    private fun queryNameAndSize(uri: Uri): Pair<String, Long> {
        context.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
        )?.use { c ->
            if (c.moveToFirst()) {
                val name = c.getString(0) ?: "image"
                val size = if (c.isNull(1)) -1L else c.getLong(1)
                return name to size
            }
        }
        return (uri.lastPathSegment ?: "image") to -1L
    }

    companion object {
        private const val RESERVE_BYTES = 512L shl 20
    }
}
