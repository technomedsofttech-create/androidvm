package com.teresa.vmmanager.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.teresa.vmmanager.VmApp
import com.teresa.vmmanager.core.qemu.GuestArch
import com.teresa.vmmanager.core.qemu.GuestProfile
import com.teresa.vmmanager.core.qemu.VmConfig
import com.teresa.vmmanager.data.VmCreator
import com.teresa.vmmanager.runtime.LaunchMode
import com.teresa.vmmanager.runtime.VmController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as VmApp
        setContent { MaterialTheme { VmListScreen(app) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VmListScreen(app: VmApp) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var vms by remember { mutableStateOf(emptyList<VmConfig>()) }
    var statuses by remember { mutableStateOf(emptyMap<String, VmController.Status>()) }
    var showCreate by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val missing = remember { app.binaries.missingPieces() }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) {
        while (true) {
            vms = app.store.list()
            statuses = vms.associate { it.id to app.controller.status(it.id) }
            delay(1500)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Virtual machines") },
                actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings") } },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, "New VM") }
        },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (missing.isNotEmpty()) item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("QEMU is not bundled in this build", style = MaterialTheme.typography.titleSmall)
                        Text("Missing: ${missing.joinToString()}. Run tools/build-qemu-android.sh and rebuild the APK.",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (vms.isEmpty()) item {
                Text("No VMs yet. Tap + and pick an Android 12, 13 or 15 image (.qcow2, .img or .iso).",
                    Modifier.padding(top = 24.dp))
            }
            items(vms, key = { it.id }) { vm ->
                VmRow(vm, statuses[vm.id]) {
                    context.startActivity(Intent(context, VmDetailActivity::class.java).putExtra("vmId", vm.id))
                }
            }
        }
    }

    if (showCreate) CreateVmDialog(app) { showCreate = false }
    if (showSettings) SettingsDialog { showSettings = false }
}

@Composable
private fun VmRow(vm: VmConfig, status: VmController.Status?, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(vm.name, style = MaterialTheme.typography.titleMedium)
                Text("${vm.profile.label} · ${vm.arch.name.lowercase()} · ${vm.ramMb / 1024.0} GB · ${vm.cpus} CPU",
                    style = MaterialTheme.typography.bodySmall)
            }
            Text(statusLabel(status), style = MaterialTheme.typography.labelLarge)
        }
    }
}

fun statusLabel(s: VmController.Status?): String = when (s) {
    is VmController.Status.Active -> s.slot.state.name.lowercase().replaceFirstChar { it.uppercase() }
    is VmController.Status.Failed -> "Failed"
    else -> "Stopped"
}

@Composable
private fun CreateVmDialog(app: VmApp, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var profile by remember { mutableStateOf(GuestProfile.ANDROID_13) }
    var arch by remember { mutableStateOf(GuestArch.X86_64) }
    var ram by remember { mutableStateOf(profile.defaultRamMb.toString()) }
    var cpus by remember { mutableStateOf("4") }
    var disk by remember { mutableStateOf(profile.defaultDiskGb.toString()) }
    var image by remember { mutableStateOf<Uri?>(null) }
    var progress by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { image = it }

    AlertDialog(
        onDismissRequest = { if (progress == null) onDismiss() },
        title = { Text("New virtual machine") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                Text("Guest Android version", style = MaterialTheme.typography.labelLarge)
                GuestProfile.values().forEach { p ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable {
                        profile = p; ram = p.defaultRamMb.toString(); disk = p.defaultDiskGb.toString()
                    }) {
                        RadioButton(selected = profile == p, onClick = null)
                        Text(p.label, Modifier.padding(start = 8.dp))
                    }
                }
                Text("Image architecture", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GuestArch.values().forEach { a ->
                        FilterChip(selected = arch == a, onClick = { arch = a }, label = { Text(a.name.lowercase()) })
                    }
                }
                Row {
                    NumberField("RAM MB", ram, Modifier.weight(1f)) { ram = it }
                    Spacer(Modifier.width(8.dp))
                    NumberField("CPUs", cpus, Modifier.weight(1f)) { cpus = it }
                }
                NumberField("Disk GB (ISO installs only)", disk, Modifier.fillMaxWidth()) { disk = it }
                TextButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                    Text(image?.lastPathSegment?.substringAfterLast('/')?.let { "Image: $it" } ?: "Choose image…")
                }
                progress?.let { Text(it) }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = image != null && progress == null,
                onClick = {
                    val req = VmCreator.Request(
                        name, profile, arch,
                        ram.toIntOrNull() ?: profile.defaultRamMb,
                        cpus.toIntOrNull() ?: 4,
                        disk.toIntOrNull() ?: profile.defaultDiskGb,
                        image!!,
                    )
                    error = null
                    progress = "Starting…"
                    scope.launch {
                        try {
                            VmCreator(app.store, app.importer, app.controller).create(req) { progress = it }
                            onDismiss()
                        } catch (e: Exception) {
                            error = e.message ?: e.toString()
                        } finally {
                            progress = null
                        }
                    }
                },
            ) { Text("Create") }
        },
        dismissButton = { TextButton(enabled = progress == null, onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun NumberField(label: String, value: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value, { v -> onChange(v.filter { it.isDigit() }.take(6)) }, modifier,
        label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
    )
}

@Composable
private fun SettingsDialog(onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var mode by remember { mutableStateOf(LaunchMode.current(context)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("How QEMU runs") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LaunchMode.values().forEach { m ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable {
                        mode = m; LaunchMode.set(context, m)
                    }) {
                        RadioButton(selected = mode == m, onClick = null)
                        Column(Modifier.padding(start = 8.dp)) {
                            Text(if (m == LaunchMode.IN_PROCESS) "Inside the app (recommended)" else "Child process")
                            Text(
                                if (m == LaunchMode.IN_PROCESS) "Needs QEMU built as a shared library. Not affected by Android's phantom-process killer."
                                else "Works with a plain QEMU executable, but Android 12+ may kill it. Disable child process restrictions in Developer options (Android 14+) or via adb (12L/13).",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
                Text("Applies to the next VM start.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}
