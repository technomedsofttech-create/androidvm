tools/build-qemu-android.sh writes libqemu-system-*.so, libqemu-img.so and dependencies here.
