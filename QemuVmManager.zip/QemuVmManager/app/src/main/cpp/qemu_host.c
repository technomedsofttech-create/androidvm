/*
 * In-process QEMU host.
 *
 * QEMU is built as a shared library (libqemu-system-<arch>.so) whose only exported symbol is
 * main(). We dlopen() it inside the VM's dedicated app process (":vm0".. ":vm3") and call main()
 * on a large-stack Java thread. Because QEMU then runs as part of the app's own process,
 * Android 12's phantom-process killer (which targets *child* processes and, on 12.0, cannot be
 * disabled without root) never sees it.
 *
 * QEMU's global state can't be reset, so the calling process is killed after main() returns.
 */
#include <jni.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#ifdef __ANDROID__
#include <android/log.h>
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "qemuhost", __VA_ARGS__)
#else
#define LOGE(...) fprintf(stderr, __VA_ARGS__)
#endif

typedef int (*qemu_main_fn)(int, char **, char **);
extern char **environ;

static char *dup_jstring(JNIEnv *env, jstring s) {
    if (s == NULL) return NULL;
    const char *utf = (*env)->GetStringUTFChars(env, s, NULL);
    if (utf == NULL) return NULL;
    char *copy = strdup(utf);
    (*env)->ReleaseStringUTFChars(env, s, utf);
    return copy;
}

/* Sends this process's stdout/stderr (QEMU's error reporting) to the VM's log file. */
static int redirect_output(const char *log_path) {
    int fd = open(log_path, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
    if (fd < 0) return -errno;
    fflush(stdout);
    fflush(stderr);
    if (dup2(fd, STDOUT_FILENO) < 0 || dup2(fd, STDERR_FILENO) < 0) {
        int e = errno;
        close(fd);
        return -e;
    }
    close(fd);
    setvbuf(stdout, NULL, _IOLBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    return 0;
}

JNIEXPORT jint JNICALL
Java_com_teresa_vmmanager_runtime_NativeQemu_nativeRun(JNIEnv *env, jclass clazz, jstring jlib,
                                                       jobjectArray jargs, jstring jlog,
                                                       jstring jtmpdir) {
    (void) clazz;
    char *lib = dup_jstring(env, jlib);
    char *log_path = dup_jstring(env, jlog);
    char *tmpdir = dup_jstring(env, jtmpdir);
    if (lib == NULL || log_path == NULL || tmpdir == NULL) return -1001;

    /* QEMU creates temp files (snapshots, memfd fallbacks) under TMPDIR; /tmp doesn't exist. */
    setenv("TMPDIR", tmpdir, 1);
    setenv("HOME", tmpdir, 1);

    int rc = redirect_output(log_path);
    if (rc != 0) LOGE("cannot open log %s: %s", log_path, strerror(-rc));

    void *handle = dlopen(lib, RTLD_NOW | RTLD_LOCAL);
    if (handle == NULL) {
        const char *err = dlerror();
        fprintf(stderr, "qemuhost: dlopen(%s) failed: %s\n", lib, err ? err : "?");
        LOGE("dlopen(%s) failed: %s", lib, err ? err : "?");
        return -1002;
    }
    /* Our build renames QEMU's main to qemu_android_main; plain "main" is the fallback for a
     * library linked with only a version script. */
    qemu_main_fn entry = (qemu_main_fn) dlsym(handle, "qemu_android_main");
    if (entry == NULL) entry = (qemu_main_fn) dlsym(handle, "main");
    if (entry == NULL) {
        fprintf(stderr, "qemuhost: no entry point in %s\n", lib);
        return -1003;
    }

    jsize argc = (*env)->GetArrayLength(env, jargs);
    char **argv = calloc((size_t) argc + 1, sizeof(char *));
    if (argv == NULL) return -1004;
    for (jsize i = 0; i < argc; i++) {
        jstring a = (jstring) (*env)->GetObjectArrayElement(env, jargs, i);
        argv[i] = dup_jstring(env, a);
        (*env)->DeleteLocalRef(env, a);
        if (argv[i] == NULL) return -1005;
    }

    fprintf(stderr, "qemuhost: starting %s with %d args\n", lib, (int) argc);
    /* Blocks for the lifetime of the VM. */
    int status = entry((int) argc, argv, environ);
    fprintf(stderr, "qemuhost: QEMU returned %d\n", status);
    fflush(stderr);
    /* Intentionally leak argv and keep the library loaded: QEMU may still reference them
     * from atexit handlers, and the process is about to be killed anyway. */
    return status;
}
