#!/usr/bin/env bash
# Builds QEMU for the VM Manager APK (arm64-v8a hosts) and drops the results into the project:
#   app/src/main/jniLibs/arm64-v8a/   libqemu-system-x86_64.so, libqemu-system-aarch64.so,
#                                     libqemu-img.so and their dependencies
#   app/src/main/assets/qemu-data/    BIOS, option ROMs, UEFI firmware, VNC keymap
#
# It reuses termux-packages' Docker build environment and its Android patches for QEMU, which
# are maintained and known to produce working QEMU binaries on Android.
#
# Requirements (Linux or macOS host): docker, git, python3, ~25 GB free disk, 1-2 hours.
# Usage: tools/build-qemu-android.sh            (uses termux-packages master)
#        TERMUX_REF=<commit> tools/build-qemu-android.sh
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="$(cd "$HERE/.." && pwd)"
WORK="${WORK:-$PROJECT/.qemu-build}"
TERMUX_REF="${TERMUX_REF:-master}"
TP="$WORK/termux-packages"
UPSTREAM="$TP/packages/qemu-system-x86-64-headless"
RECIPE="$TP/packages/qemu-vmmanager"

for tool in docker git python3; do
	command -v "$tool" >/dev/null || { echo "missing required tool: $tool" >&2; exit 1; }
done

mkdir -p "$WORK"
if [ ! -d "$TP/.git" ]; then
	git clone --filter=blob:none https://github.com/termux/termux-packages "$TP"
fi
git -C "$TP" fetch --depth 1 origin "$TERMUX_REF"
git -C "$TP" checkout --force FETCH_HEAD

echo "==> generating packages/qemu-vmmanager from $(basename "$UPSTREAM")"
rm -rf "$RECIPE"
mkdir -p "$RECIPE"
cp "$UPSTREAM"/*.patch "$RECIPE/"
cp -r "$UPSTREAM/setjmp-aarch64" "$RECIPE/"
upstream_vars="$(grep -E '^TERMUX_PKG_(VERSION|SRCURL|SHA256)=' "$UPSTREAM/build.sh")"
[ "$(printf '%s\n' "$upstream_vars" | wc -l)" -eq 3 ] || { echo "unexpected upstream recipe format" >&2; exit 1; }
python3 - "$HERE/qemu-recipe/build.sh.in" "$RECIPE/build.sh" "$upstream_vars" <<'EOF'
import sys
src, dst, upstream = sys.argv[1:4]
text = open(src).read().replace("@UPSTREAM_VARS@", upstream)
open(dst, "w").write(text)
EOF
echo "    $(printf '%s' "$upstream_vars" | head -1)"

echo "==> building inside the termux-packages Docker image (first run downloads it)"
# -I: download already-built dependencies (glib, pixman, slirp, ...) from Termux's repository.
(cd "$TP" && ./scripts/run-docker.sh ./build-package.sh -I -f -a aarch64 qemu-vmmanager)

OUT="$TP/output-vmmanager"
[ -f "$OUT/lib/libqemu-system-x86_64.so" ] || { echo "build finished but $OUT is incomplete" >&2; exit 1; }

echo "==> repackaging libraries for the APK"
python3 -m pip install --quiet --user patchelf 2>/dev/null || true
python3 "$HERE/repackage_libs.py" "$OUT/lib" "$PROJECT/app/src/main/jniLibs/arm64-v8a"

echo "==> copying firmware"
rm -rf "$PROJECT/app/src/main/assets/qemu-data"
mkdir -p "$PROJECT/app/src/main/assets"
cp -r "$OUT/qemu-data" "$PROJECT/app/src/main/assets/qemu-data"

echo "==> done. Rebuild the APK: ./gradlew assembleDebug"
