import com.teresa.vmmanager.core.adb.AdbConnection;
import com.teresa.vmmanager.core.adb.AdbKeyPair;
import com.teresa.vmmanager.core.adb.GuestPackages;
import com.teresa.vmmanager.core.io.Transport;
import com.teresa.vmmanager.core.qmp.QmpClient;
import com.teresa.vmmanager.core.rfb.RfbClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnixDomainSocketAddress;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import java.util.Random;

/**
 * Drives the core clients against tools/fakes/fake_guest.py over real unix sockets.
 * Usage: java IntegrationCheck adbd|rfb|qmp <socket> [workdir]
 */
public class IntegrationCheck {
    static final class UnixTransport implements Transport {
        final SocketChannel ch;
        UnixTransport(String path) throws IOException {
            ch = openWithRetry(path);
        }
        static SocketChannel openWithRetry(String path) throws IOException {
            IOException last = null;
            for (int i = 0; i < 50; i++) {
                try {
                    return SocketChannel.open(UnixDomainSocketAddress.of(path));
                } catch (IOException e) {
                    last = e;
                    try { Thread.sleep(100); } catch (InterruptedException ignored) { }
                }
            }
            throw last;
        }
        public InputStream input() { return Channels.newInputStream(ch); }
        public OutputStream output() { return Channels.newOutputStream(ch); }
        public void close() throws IOException { ch.close(); }
    }

    static void check(boolean ok, String what) {
        if (!ok) throw new AssertionError(what);
        System.out.println("  ok: " + what);
    }

    public static void main(String[] args) throws Exception {
        switch (args[0]) {
            case "adbd": adb(args[1], Path.of(args[2])); break;
            case "rfb": rfb(args[1]); break;
            case "qmp": qmp(args[1]); break;
            default: throw new IllegalArgumentException(args[0]);
        }
    }

    static void adb(String sock, Path work) throws Exception {
        AdbKeyPair key = AdbKeyPair.loadOrCreate(work.resolve("keys"));
        boolean[] prompted = {false};
        byte[] apk = new byte[10_000 + 4096 * 3 + 17];
        new Random(42).nextBytes(apk);
        try (AdbConnection c = AdbConnection.connect(new UnixTransport(sock), key, "vmmanager@test",
                () -> prompted[0] = true, 5000, 5000)) {
            check(prompted[0], "first connection asks the guest to approve our key");
            check(c.banner().startsWith("device::"), "CNXN banner received");
            List<String> apps = GuestPackages.parseLaunchable(c.exec(GuestPackages.LIST_LAUNCHABLE));
            check(apps.size() == 2 && apps.contains("org.example.notes"), "launchable apps parsed: " + apps);
            long[] last = {0};
            String out = c.install(new ByteArrayInputStream(apk), apk.length, (s, t) -> last[0] = s);
            check(GuestPackages.installSucceeded(out), "install reports Success");
            check(last[0] == apk.length, "progress reached 100%");
            Files.writeString(work.resolve("apk.sha256"),
                    HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(apk)));
        }
        AdbKeyPair reloaded = AdbKeyPair.loadOrCreate(work.resolve("keys"));
        boolean[] prompted2 = {false};
        try (AdbConnection c = AdbConnection.connect(new UnixTransport(sock), reloaded, "vmmanager@test",
                () -> prompted2[0] = true, 5000, 5000)) {
            check(!prompted2[0], "second connection authenticates by signature (saved key reused)");
            check(c.exec(GuestPackages.launchCommand("org.example.notes")).contains("Events injected"), "launch via monkey");
        }
    }

    static void rfb(String sock) throws Exception {
        int[] updates = {0};
        boolean[] bell = {false};
        RfbClient[] holder = new RfbClient[1];
        RfbClient c = new RfbClient(new UnixTransport(sock), new RfbClient.Listener() {
            public void onResize(int w, int h) { }
            public void onFramebufferUpdate(int x, int y, int w, int h) {
                updates[0]++;
                try {
                    RfbClient r = holder[0];
                    if (updates[0] == 1) {
                        int[] px = new int[12];
                        check(r.copyFramebuffer(px, 4, 3), "first frame 4x3");
                        check(px[1 * 4 + 2] == 0xFF140A07, "raw pixel (2,1) = rgb(20,10,7)");
                        check(px[2 * 4 + 3] == 0xFF001407, "copyrect moved column 0 into column 3");
                    } else if (updates[0] == 2) {
                        int[] px = new int[48];
                        check(r.copyFramebuffer(px, 8, 6), "resized to 8x6");
                        check(px[5 * 8 + 7] == 0xFFFF0000, "raw red block after resize");
                        r.sendPointer(3, 2, RfbClient.BUTTON_LEFT);
                        r.sendKey(0xff1b, true);
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            public void onBell() { bell[0] = true; }
        });
        holder[0] = c;
        c.handshake();
        check("fake-guest".equals(c.desktopName()), "server name read");
        try {
            c.runLoop();
        } catch (IOException expectedWhenServerCloses) {
        }
        check(updates[0] == 2 && bell[0], "two updates and a bell processed");
    }

    static void qmp(String sock) throws Exception {
        try (QmpClient q = QmpClient.connect(new UnixTransport(sock), 5000)) {
            check("running".equals(q.status()), "query-status skips event and parses status");
            try {
                q.execute("bogus");
                check(false, "error reply should throw");
            } catch (IOException e) {
                check(e.getMessage().contains("CommandNotFound"), "error reply surfaces as exception");
            }
            q.powerdown();
            q.quit();
        }
    }
}
