#!/usr/bin/env python3
"""
Fake guest endpoints for developing the manager without QEMU:
  adbd  - CNXN/AUTH (verifies the RSA signature with the Android-format public key it receives),
          exec: commands and streamed "cmd package install -S"
  rfb   - VNC 3.8 server with raw, copyrect and desktop-size updates
  qmp   - QMP greeting, qmp_capabilities, query-status (with an interleaved event), quit

Usage: fake_guest.py adbd|rfb|qmp <unix-socket-path> [report-file]
Each server handles the connections its integration test expects, then exits.
"""
import base64, hashlib, json, os, socket, struct, sys

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa, utils


def listen(path):
    if os.path.exists(path):
        os.unlink(path)
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind(path)
    s.listen(4)
    return s


def recv_exact(c, n):
    buf = b""
    while len(buf) < n:
        chunk = c.recv(n - len(buf))
        if not chunk:
            raise EOFError("peer closed")
        buf += chunk
    return buf


# ---------------------------------------------------------------- adbd
CNXN, OPEN, OKAY, CLSE, WRTE, AUTH = (int.from_bytes(x, "little") for x in (b"CNXN", b"OPEN", b"OKAY", b"CLSE", b"WRTE", b"AUTH"))


def adb_send(c, cmd, a0, a1, data=b""):
    c.sendall(struct.pack("<6I", cmd, a0, a1, len(data), sum(data) & 0xFFFFFFFF, cmd ^ 0xFFFFFFFF) + data)


def adb_recv(c):
    cmd, a0, a1, ln, _crc, magic = struct.unpack("<6I", recv_exact(c, 24))
    assert magic == cmd ^ 0xFFFFFFFF, "bad magic"
    return cmd, a0, a1, recv_exact(c, ln) if ln else b""


def parse_android_pubkey(payload):
    blob = payload.rstrip(b"\0").split(b" ", 1)[0]
    raw = base64.b64decode(blob)
    words, = struct.unpack_from("<I", raw, 0)
    n = int.from_bytes(raw[8:8 + words * 4], "little")
    e, = struct.unpack_from("<I", raw, 8 + words * 8)
    return rsa.RSAPublicNumbers(e, n).public_key()


def verify(pub, token, sig):
    try:
        pub.verify(sig, token, padding.PKCS1v15(), utils.Prehashed(hashes.SHA1()))
        return True
    except Exception:
        return False


def run_adbd(path, report):
    srv = listen(path)
    known = None
    results = {"connections": 0, "installs": []}
    for _ in range(2):  # 1st: key unknown -> pubkey flow, 2nd: signature accepted directly
        c, _ = srv.accept()
        results["connections"] += 1
        cmd, a0, a1, data = adb_recv(c)
        assert cmd == CNXN and data.startswith(b"host::"), "expected CNXN"
        token = os.urandom(20)
        adb_send(c, AUTH, 1, 0, token)
        cmd, a0, _, sig = adb_recv(c)
        assert cmd == AUTH and a0 == 2
        if known is not None and verify(known, token, sig):
            results["second_auth"] = "signature"
        else:
            adb_send(c, AUTH, 1, 0, os.urandom(20))
            cmd, a0, _, pubdata = adb_recv(c)
            assert cmd == AUTH and a0 == 3, "expected public key"
            pub = parse_android_pubkey(pubdata)
            results["first_auth_sig_valid"] = verify(pub, token, sig)
            results["key_name"] = pubdata.rstrip(b"\0").split(b" ", 1)[1].decode()
            known = pub
        adb_send(c, CNXN, 0x01000001, 4096, b"device::ro.product.name=fake;features=cmd\0")
        remote = 100
        while True:
            try:
                cmd, a0, a1, data = adb_recv(c)
            except EOFError:
                break
            if cmd != OPEN:
                continue
            local = a0
            remote += 1
            dest = data.rstrip(b"\0").decode()
            adb_send(c, OKAY, remote, local)
            if dest.startswith("exec:cmd package install -r -S "):
                size = int(dest.rsplit(" ", 1)[1])
                h, got = hashlib.sha256(), 0
                while got < size:
                    cmd, _, _, data = adb_recv(c)
                    assert cmd == WRTE, "expected WRTE"
                    assert len(data) <= 4096, "client ignored maxdata"
                    h.update(data)
                    got += len(data)
                    adb_send(c, OKAY, remote, local)
                results["installs"].append({"size": got, "sha256": h.hexdigest()})
                out = b"Success\n"
            elif dest.startswith("exec:cmd package query-activities"):
                out = b"com.android.settings/.Settings\norg.example.notes/.Main\n" * 1
            elif dest.startswith("exec:monkey -p "):
                out = b"Events injected: 1\n"
            else:
                out = ("unknown: " + dest + "\n").encode()
            # split output into two WRTEs to exercise buffering
            for part in (out[: len(out) // 2], out[len(out) // 2:]):
                adb_send(c, WRTE, remote, local, part)
                cmd, _, _, _ = adb_recv(c)
                assert cmd == OKAY, "client must OKAY each WRTE"
            adb_send(c, CLSE, remote, local)
            cmd, _, _, _ = adb_recv(c)
            assert cmd == CLSE, "client must echo CLSE"
        c.close()
    json.dump(results, open(report, "w"))


# ---------------------------------------------------------------- rfb
def px(r, g, b):
    return bytes([b, g, r, 0])  # 32bpp little-endian 0x00RRGGBB as requested by the client


def run_rfb(path, report):
    srv = listen(path)
    c, _ = srv.accept()
    c.sendall(b"RFB 003.008\n")
    ver = recv_exact(c, 12)
    c.sendall(bytes([1, 1]))
    sec = recv_exact(c, 1)
    c.sendall(struct.pack(">I", 0))
    shared = recv_exact(c, 1)
    name = b"fake-guest"
    c.sendall(struct.pack(">HH", 4, 3) + bytes(16) + struct.pack(">I", len(name)) + name)
    setpf = recv_exact(c, 20)
    enc_hdr = recv_exact(c, 4)
    encs = struct.unpack(">%di" % enc_hdr[3], recv_exact(c, 4 * enc_hdr[3]))
    req1 = recv_exact(c, 10)
    # update 1: full 4x3 raw, pixel (x,y) = rgb(x*10, y*10, 7); then copyrect col0 -> col3
    raw = b"".join(px(x * 10, y * 10, 7) for y in range(3) for x in range(4))
    msg = struct.pack(">BBH", 0, 0, 2)
    msg += struct.pack(">HHHHi", 0, 0, 4, 3, 0) + raw
    msg += struct.pack(">HHHHi", 3, 0, 1, 3, 1) + struct.pack(">HH", 0, 0)
    c.sendall(msg)
    req2 = recv_exact(c, 10)
    # update 2: desktop resize to 8x6, then a raw 2x2 red block at (6,4)
    msg = struct.pack(">BBH", 0, 0, 2)
    msg += struct.pack(">HHHHi", 0, 0, 8, 6, -223)
    msg += struct.pack(">HHHHi", 6, 4, 2, 2, 0) + px(255, 0, 0) * 4
    c.sendall(msg + bytes([2]))  # + Bell
    events = []
    data = b""
    c.settimeout(5)
    try:
        while len(events) < 3:
            t = recv_exact(c, 1)[0]
            if t == 3:
                recv_exact(c, 9)
                events.append("req")
            elif t == 5:
                mask, x, y = struct.unpack(">BHH", recv_exact(c, 5))
                events.append(["ptr", mask, x, y])
            elif t == 4:
                down, _, key = struct.unpack(">BHI", recv_exact(c, 7))
                events.append(["key", down, key])
    except Exception as e:
        events.append("err:" + str(e))
    c.close()
    json.dump({
        "client_version": ver.decode(), "security": sec[0], "shared": shared[0],
        "bpp": setpf[4], "depth": setpf[5], "true_colour": setpf[7], "shifts": list(setpf[14:17]),
        "encodings": list(encs), "first_request_incremental": req1[1], "second_request_incremental": req2[1],
        "events": events,
    }, open(report, "w"))


# ---------------------------------------------------------------- qmp
def run_qmp(path, report):
    srv = listen(path)
    c, _ = srv.accept()
    f = c.makefile("rwb")
    f.write(b'{"QMP": {"version": {"qemu": {"major": 9}}, "capabilities": []}}\r\n'); f.flush()
    seen = []
    for line in f:
        cmd = json.loads(line)["execute"]
        seen.append(cmd)
        if cmd == "query-status":
            f.write(b'{"timestamp": {}, "event": "RTC_CHANGE", "data": {}}\r\n')
            f.write(b'{"return": {"status": "running", "running": true}}\r\n')
        elif cmd == "bogus":
            f.write(b'{"error": {"class": "CommandNotFound", "desc": "nope"}}\r\n')
        else:
            f.write(b'{"return": {}}\r\n')
        f.flush()
        if cmd == "quit":
            break
    c.close()
    json.dump({"commands": seen}, open(report, "w"))


if __name__ == "__main__":
    kind, sock = sys.argv[1], sys.argv[2]
    rep = sys.argv[3] if len(sys.argv) > 3 else os.devnull
    {"adbd": run_adbd, "rfb": run_rfb, "qmp": run_qmp}[kind](sock, rep)
