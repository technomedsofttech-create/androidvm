#!/usr/bin/env python3
"""
Makes a directory of Termux-built ELF files installable as Android jniLibs.

Android only extracts files named lib*.so from an APK, and looks dependencies up by exact
DT_NEEDED name inside nativeLibraryDir. Termux libraries use versioned names
(libglib-2.0.so.0, libz.so.1, ...) and an RUNPATH into /data/data/com.termux. This script:
  - renames every library to a lib*.so name and rewrites SONAME/DT_NEEDED to match
  - maps libraries Android already provides (libz) to the system copy instead of bundling them
  - removes RUNPATH/RPATH
  - warns about LOAD segments aligned below 16 KB (they won't load on 16 KB-page devices)

Usage: repackage_libs.py <termux-output-lib-dir> <app/src/main/jniLibs/arm64-v8a>
Needs `patchelf` on PATH (pip install patchelf).
"""
import os
import re
import shutil
import struct
import subprocess
import sys

# Libraries the app process already gets from Android (NDK stable public libraries).
SYSTEM = {
    "libc.so", "libm.so", "libdl.so", "liblog.so", "libandroid.so", "libz.so", "libEGL.so",
    "libGLESv2.so", "libGLESv3.so", "libvulkan.so", "libjnigraphics.so", "libnativewindow.so",
    "libOpenSLES.so", "libaaudio.so", "libmediandk.so", "libsync.so", "libstdc++.so",
}
# Versioned Termux names that should resolve to the Android system library.
SYSTEM_ALIASES = {"libz.so.1": "libz.so"}
APP_OWNED = {"libqemuhost.so"}  # built by the app's own CMake project


def patchelf(*args):
    exe = shutil.which("patchelf")
    if exe is None:
        sys.exit("patchelf not found: pip install patchelf")
    return subprocess.run([exe, *args], check=True, capture_output=True, text=True).stdout


def is_elf(path):
    with open(path, "rb") as f:
        return f.read(4) == b"\x7fELF"


def soname(path):
    try:
        s = patchelf("--print-soname", path).strip()
        return s or os.path.basename(path)
    except subprocess.CalledProcessError:
        return os.path.basename(path)  # executables have no SONAME


def needed(path):
    return [n for n in patchelf("--print-needed", path).split() if n]


def android_name(name, taken):
    """libglib-2.0.so.0 -> libglib-2.0.so ; foo.so.1 -> libfoo.so ; collisions -> libx_1.so"""
    base = re.sub(r"\.so(\.[0-9.]+)?$", "", name)
    if not base.startswith("lib"):
        base = "lib" + base
    candidate = base + ".so"
    m = re.search(r"\.so\.([0-9.]+)$", name)
    if candidate in taken or candidate in SYSTEM or candidate in APP_OWNED:
        suffix = m.group(1).replace(".", "_") if m else "x"
        candidate = f"{base}_{suffix}.so"
    return candidate


def min_load_alignment(path):
    with open(path, "rb") as f:
        data = f.read(1 << 16)
    if data[4] != 2:  # not ELF64
        return None
    phoff, = struct.unpack_from("<Q", data, 0x20)
    phentsize, phnum = struct.unpack_from("<HH", data, 0x36)
    aligns = []
    for i in range(phnum):
        off = phoff + i * phentsize
        p_type, = struct.unpack_from("<I", data, off)
        if p_type == 1:  # PT_LOAD
            aligns.append(struct.unpack_from("<Q", data, off + 0x30)[0])
    return min(aligns) if aligns else None


def main():
    src, dst = sys.argv[1], sys.argv[2]
    os.makedirs(dst, exist_ok=True)
    files = sorted(f for f in os.listdir(src) if is_elf(os.path.join(src, f)))

    rename, taken = {}, set()
    for f in files:
        so = soname(os.path.join(src, f))
        if so in SYSTEM_ALIASES:
            continue  # use Android's copy
        new = f if re.fullmatch(r"lib.+\.so", f) and f not in taken else android_name(so, taken)
        rename[so] = new
        rename[f] = new
        taken.add(new)

    written = []
    for f in files:
        so = soname(os.path.join(src, f))
        if so in SYSTEM_ALIASES:
            continue
        out = os.path.join(dst, rename[f])
        shutil.copy2(os.path.join(src, f), out)
        os.chmod(out, 0o755)
        patchelf("--remove-rpath", out)
        if rename.get(so) and f.startswith("lib") and "qemu-img" not in f:
            try:
                patchelf("--set-soname", rename[so], out)
            except subprocess.CalledProcessError:
                pass  # executables have no SONAME
        for n in needed(out):
            target = SYSTEM_ALIASES.get(n) or rename.get(n)
            if target and target != n:
                patchelf("--replace-needed", n, target, out)
            elif not target and n not in SYSTEM:
                print(f"WARNING: {rename[f]} needs {n}, which is neither bundled nor a system library")
        written.append(rename[f])

    for name in written:
        a = min_load_alignment(os.path.join(dst, name))
        if a is not None and a < 0x4000:
            print(f"note: {name} has {a:#x} LOAD alignment; it will not load on 16 KB-page devices")
    print(f"wrote {len(written)} libraries to {dst}")


if __name__ == "__main__":
    main()
