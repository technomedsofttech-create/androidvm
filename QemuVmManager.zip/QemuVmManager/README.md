# VM Manager — no-root QEMU Android VMs on Android 12+ phones

Runs multiple independent Android 12 / 13 / 15 guests on an arm64 Android 12+ phone with QEMU
(TCG software emulation — no root, no KVM), installs APKs into them, and pins home-screen
shortcuts that boot a VM and open a guest app.

## Status of this step

| Piece | State |
|---|---|
| QEMU command builder (q35 / virt, TCG, virtio, private sockets) | Done, unit-tested |
| ADB client (CNXN, RSA AUTH, exec, streamed `cmd package install`) | Done, tested against a fake adbd that independently verifies the RSA signature |
| VNC client (RFB 3.8, raw / copyrect / resize, pointer, keys) | Done, tested against a fake VNC server |
| QMP client (status, powerdown, quit) | Done, tested against a fake QMP server |
| Per-VM process slots (`:vm0`..`:vm3`), foreground service, crash isolation | Written, not yet run on a device |
| In-process QEMU loader (JNI `dlopen` + `main`) | Written; relink + dlopen technique verified on a toy meson project |
| QEMU-for-Android build (Termux recipe → shared libs → jniLibs) | Written; not yet run end-to-end (needs Docker + ~1-2 h) |
| UI: VM list, create from image, detail, display, APK install, shortcuts | Written, not yet compiled (no Android SDK in the sandbox it was written in) |

## Build the APK in the cloud (no PC needed)

1. Create a new GitHub repository and upload the contents of this folder (including `.github/`).
2. Pushing to `main` runs **Actions → Build APK** automatically. When it finishes, open the run
   and download the **VmManager-debug-apk** artifact (a zip containing the .apk).
3. For an APK that can actually run VMs: Actions → Build APK → **Run workflow** → tick
   "Also build QEMU". That run takes 1-3 hours.

## Build locally

1. **Build QEMU** (Linux/macOS with Docker, ~25 GB free):
   ```
   tools/build-qemu-android.sh
   ```
   This generates a trimmed recipe from Termux's maintained `qemu-system-x86-64-headless`
   (QEMU 11.1.x with Termux's Android patches), builds it in Termux's Docker image, relinks
   `qemu-system-x86_64` / `qemu-system-aarch64` as shared libraries exporting only `main`,
   bundles dependencies with Android-legal names, and copies firmware into `assets/qemu-data`.
2. **Build the app**: open in Android Studio (Ladybug or newer) or `gradle wrapper && ./gradlew assembleDebug`.
   Until step 1 has run, the app shows a "QEMU is not bundled" banner.

## Guest images

Plain QEMU can't boot stock phone firmware or the Android Emulator's images (those need the
emulator's own "ranchu" machine). Use images built for PC-style virtual hardware:

| Guest | Practical image | Notes |
|---|---|---|
| Android 12 | Bliss OS 15 (Android 12L), x86_64 | Install from ISO to the VM disk, or import a prepared .qcow2 |
| Android 13 | Bliss OS 16, x86_64 | Same |
| Android 15 | AOSP x86_64 or arm64 build you make yourself, or a community x86_64 build | No widely maintained prebuilt image confirmed; `GuestArch.AARCH64` + UEFI is supported for arm64 builds |

Create a VM → pick the image. A `.qcow2`/`.img` becomes a shared read-only base with a per-VM
copy-on-write overlay, so several VMs can share one base. An `.iso` gets a blank disk plus the ISO
as a CD-ROM; eject it in VM details after installing.

**Guest adb**: APK install, app listing, shortcuts and the Back/Home/Apps buttons use adbd inside
the guest on TCP 5555. Enable USB debugging in the guest's Developer options; if adbd isn't on TCP,
run `setprop service.adb.tcp.port 5555; stop adbd; start adbd` as root in the guest. The first
connection shows "Allow debugging?" in the guest — accept it once ("Always allow").

## Architecture

```
MainActivity / VmDetailActivity (Compose)      DisplayActivity (one Recents entry per VM)
        │ start/stop                                   │ VNC over unix socket  │ adb over 127.0.0.1
        ▼                                              ▼                       ▼
VmController ──startForegroundService──► VmSlotNService in process :vmN ─► QEMU (dlopen'd, main())
SlotRegistry (files/slots/N.json)              -vnc unix:…/vnc.sock  -qmp unix:…/qmp.sock
                                               slirp hostfwd 127.0.0.1:1655N → guest :5555
```

- **Why in-process QEMU**: Android 12+ kills "phantom" (child) processes that use a lot of CPU,
  and on 12.0 that can't be turned off without root. QEMU as a child process is exactly that.
  Loading it as a library inside the app's own `:vmN` process sidesteps it. A child-process mode
  remains in Settings for builds that only have executables (on 12L/13: `adb shell settings put
  global settings_enable_monitor_phantom_procs false`; on 14+: Developer options → "Disable child
  process restrictions").
- **Why one process per VM**: QEMU's global state can't be reset and it calls `exit()` on errors.
  Separate processes keep VMs independent and the UI alive; the slot process is killed when its
  QEMU exits. Four slots (= four concurrent VMs; add more `VmSlotNService` entries for more).
- **Security**: VNC and QMP listen only on unix sockets in the app's private dir. adb is reachable
  on 127.0.0.1 only, and the guest's adbd requires the manager's RSA key.

## Testing what can run without a phone

```
# core unit tests (JUnit)
./gradlew :app:testDebugUnitTest
# protocol integration against fakes (Java 17+, python3 + cryptography)
python3 tools/fakes/fake_guest.py adbd /tmp/a.sock /tmp/r.json & java -cp <core classes> IntegrationCheck adbd /tmp/a.sock /tmp/w
```

## Still required for a working VM

1. **Run the QEMU build** and fix whatever the first real build surfaces (most likely: a configure
   flag a Termux patch depends on, or the relink step if QEMU's link line has an unusual shape).
2. **First on-device bring-up**: confirm QEMU runs inside an ART process — QEMU installs signal
   handlers and blocks signals; ART chains them via libsigchain, but this must be observed working.
3. **Firmware check**: confirm `bios-256k.bin`, `efi-virtio.rom`, `vgabios-virtio.bin`,
   `keymaps/en-us` and `edk2-aarch64-code.fd` landed in `assets/qemu-data`.
4. **A guest image that boots** under `q35 + virtio-vga + HWACCEL=0` (software rendering).
5. **Performance expectations**: TCG emulating x86_64 on an ARM phone is roughly 10-30x slower than
   native. Expect multi-minute boots and laggy UI; give the VM 4 vCPUs on an 8-core phone and keep
   the screen on. This is inherent to no-root emulation (no KVM/AVF access for third-party apps).
6. **16 KB page devices**: QEMU and the JNI shim are linked for 16 KB pages; Termux dependency
   libraries may not be. `repackage_libs.py` warns about each one.
7. Nice-to-have next steps: real app icons for shortcuts (pull icon from the guest APK), clipboard
   sync, audio (currently disabled), VNC Tight/ZRLE encodings for speed, snapshots via QMP.
